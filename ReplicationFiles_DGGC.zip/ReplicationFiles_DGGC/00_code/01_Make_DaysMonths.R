################################################################################################
#
#                           This File Creates Synthetic Data
#
#       I)    Syntehtic Days
#       II)   Synthetic Months
#
################################################################################################

rm(list = ls())

# ============================================== USER INTERACTION: Start ============================================== #

directory <- "/Users/maximilian/Dropbox/ReplicationFiles"

# ============================================== USER INTERACTION: End ============================================== #


for (mm in c("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC")){
  for (ind in c("SII","SIT","CO2","AT")){
    
    
#   Define your targeted month "m.star"
m.star <- mm #"SEP"

#   Which series do you want to prepare?   
#   "SII" = Sea Ice Index (Extent); "SIT" = PIOMAS Thickness; "CO2" = Mauna Loa Global CO2; "AT" = NH Temperature Anomaly
I.want.ICE <- ind #"SII" 

#   Do you want to the data to be in First-Differences? ["yes"/"no"] --> only for: CO2
if (ind %in% c("CO2","AT")){
  I.want.FD <- "yes"
} else{
  I.want.FD <- "no"
}



#   Load the raw data
if (I.want.ICE == "SII"){
  SII_df <- read.csv(file.path(directory,"10_data/SeaIceIndex_Daily.csv"))
  prefix <- c()
} else if (I.want.ICE == "SIT"){
  source(file = file.path(directory,"00_code/001_functions/preprocessSIT.R"))
  
  SIT_df <- preprocessSIT(directory=paste0(directory,"/10_data/"))
  
  #   Prefix has to be the same name as the data-column, with a "." as an addendum
  prefix <- c("SIT.")
  
} else if (I.want.ICE == "CO2"){
  CO2_df <- read.csv(file.path(directory,"10_data/CO2_monthly.csv"))

  if (I.want.FD == "yes"){
    CO2_df$CO2 <- c(NA, CO2_df$CO2[2:nrow(CO2_df)] - CO2_df$CO2[1:(nrow(CO2_df)-1)])
  }
  
  CO2_df <- CO2_df[-1,]
  prefix <- c("CO2.")
  
} else if (I.want.ICE == "AT"){
  AT_df <- read.csv(file.path(directory,"10_data/AT_monthly.csv"))
  
  if (I.want.FD == "yes"){
    AT_df$AT <- c(NA, AT_df$AT[2:nrow(AT_df)] - AT_df$AT[1:(nrow(AT_df)-1)])
  }
  
  AT_df <- AT_df[-1,]
  prefix <- c("AT.")
}


#   Now bring data in your desired format

if (I.want.ICE == "SII"){
  
  source(file = file.path(directory,"00_code/001_functions/getSII.R"))
  SII <- getSII(SII_df, m.star)
  
  #   Export the real observations
  write.csv(SII$SII_real.obs.panel, 
            file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs.csv")), 
            row.names = T)
  
  #   Export the synthetic data
  write.csv(SII$SII_processed_nomissing_synthetic, 
            file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                               "_processed_nomissing_synthetic",m.star,".csv")), row.names = T)
  
} else if (I.want.ICE == "SIT"){
  
  source(file = file.path(directory,"00_code/001_functions/getSIT.R"))
  SIT <- getSIT(SIT_df, m.star, prefix)
  
  #   Export the real observations
  write.csv(SIT$SIT_real.obs.panel, 
            file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs.csv")), 
            row.names = T)
  
  #   Export the synthetic data
  write.csv(SIT$SIT_processed_nomissing_synthetic, 
            file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                               "_processed_nomissing_synthetic",m.star,".csv")), row.names = T)
  
} else if (I.want.ICE == "CO2"){
  
  source(file = file.path(directory,"00_code/001_functions/getCO2.R"))
  CO2 <- getCO2(CO2_df, m.star, prefix)
  
  #   Export the real observations
  if (I.want.FD == "yes"){
    write.csv(CO2$CO2_real.obs.panel,#[-which(rownames(CO2$CO2_real.obs.panel) == "2021"),], 
              file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs_FD.csv")), 
              row.names = T)
  } else{
    write.csv(CO2$CO2_real.obs.panel,#[-which(rownames(CO2$CO2_real.obs.panel) == "2021"),], 
              file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs.csv")), 
              row.names = T)
  }
  
  #   Export the synthetic data
  if (I.want.FD == "yes"){
    write.csv(CO2$CO2_processed_nomissing_synthetic,#[-which(rownames(CO2$CO2_processed_nomissing_synthetic) == "2021"),],
              file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                                 "_processed_nomissing_synthetic",m.star,"_FD.csv")), row.names = T)
  } else{
    write.csv(CO2$CO2_processed_nomissing_synthetic,#[-which(rownames(CO2$CO2_processed_nomissing_synthetic) == "2021"),],
              file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                                 "_processed_nomissing_synthetic",m.star,".csv")), row.names = T)
  }
  
} else if (I.want.ICE == "AT"){
  
  source(file = file.path(directory,"00_code/001_functions/getCO2.R"))
  AT <- getCO2(AT_df, m.star, prefix)
  
  #   Export the real observations
  if (I.want.FD == "yes"){
    write.csv(AT$AT_real.obs.panel,#[-which(rownames(AT$AT_real.obs.panel) == "2021"),], 
              file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs_FD.csv")), 
              row.names = T)
  } else{
    write.csv(AT$AT_real.obs.panel,#[-which(rownames(AT$AT_real.obs.panel) == "2021"),], 
              file = file.path(directory, paste0("10_data/", I.want.ICE,"_processed_nomissing_realobs.csv")), 
              row.names = T)
  }
  
  #   Export the synthetic data
  if (I.want.FD == "yes"){
    write.csv(AT$AT_processed_nomissing_synthetic,#[-which(rownames(AT$AT_processed_nomissing_synthetic) == "2021"),],
              file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                                 "_processed_nomissing_synthetic",m.star,"_FD.csv")), row.names = T)
  } else{
    write.csv(AT$AT_processed_nomissing_synthetic,#[-which(rownames(AT$AT_processed_nomissing_synthetic) == "2021"),],
              file = file.path(directory, paste0("10_data/SyntheticData/", I.want.ICE,
                                                 "_processed_nomissing_synthetic",m.star,".csv")), row.names = T)
  }
}


  }}
