# =========================================================================================== #
#
#
#                   This tool downloads the necessary data files
# 
#
# =========================================================================================== #

# %%
# ========================  Global Variables - USER INTERACTION ===================================== #

# --- Define the general directory
directory = '/Users/maximilian/Dropbox/'

# --- Set the sub-directory you would like to download the files to
directory_data =  '10_data/100_RawData/'

# ========================  Global Variables - USER INTERACTION ===================================== #



# %%
# =========================================================================================== #
#
#                               NSIDC -- Daily Sea Ice Index 
#                       ( see: https://nsidc.org/support/64231694-FTP-Client-Data-Access#python )
#
# =========================================================================================== #


from ftplib import FTP
import os
import pandas as pd
import numpy as np

# %%
# ========================      USER INTERACTION     ===================================== #

# --- Set the password which will be your email address
password = 'maximilian.goebel@phd.iseg.ulisboa.pt'

# ========================      USER INTERACTION     ===================================== #


# %%
# ========================      Start the Download     ===================================== #

# Path to output directory
destdir = directory + directory_data

# Path to the FTP directory that contains the data you wish to download -- DO NOT TOUCH!
directory_NSIDC = '/DATASETS/NOAA/G02135/north/daily/data'

# FTP server ------------------------ DO NOT TOUCH!
ftpdir = 'sidads.colorado.edu'

# Connect and log in to the FTP
print('Logging in')
ftp = FTP(ftpdir)
ftp.login('anonymous',password)

# Change to the directory where the files are on the FTP
print('Changing to '+ directory_NSIDC)
ftp.cwd(directory_NSIDC)

# Get a list of the files in the FTP directory
files = ftp.nlst()
files = files[2:]
print(files)

# Change to the destination directory on own computer where you want to save the files
os.chdir(destdir)

# Download:      We are only interested in the daily-CSV-file
#for file in files:
file = 'N_seaice_extent_daily_v3.0.csv'
print('Downloading...' + file)
ftp.retrbinary('RETR ' + file, open(file, 'wb').write)

#Close the FTP connection
ftp.quit()

# %%
# ========================      Clean the Data     ===================================== #

# --- Load the latest file
SIE_latest = pd.read_csv(directory + directory_data + "N_seaice_extent_daily_v3.0.csv",
                         skiprows=[1])

# --- Load the working/production file
SIE_prod = pd.read_csv(directory + "/10_data/SeaIceIndex_daily.csv")


# --- Get the latest observations that you have:
year_prod = int(SIE_prod.Year[-1:])
month_prod = int(SIE_prod.Month[-1:])
day_prod = int(SIE_prod.Day[-1:])

# --- Append all NEW observations
idx = SIE_latest.loc[(SIE_latest['Year'] == year_prod) & \
                    (SIE_latest[' Month'] == month_prod) & \
                    (SIE_latest[' Day'] == day_prod),:].index[0]

SIE_out = pd.DataFrame(np.vstack((SIE_prod,np.array(SIE_latest.loc[(idx+1):, ['Year', ' Month', ' Day','     Extent']]))),
                        columns=SIE_prod.columns)

# --- Export as the new production file:
SIE_out.to_csv(directory + '/10_data/SeaIceIndex_daily.csv', index=False)
     

# %%
# =========================================================================================== #
#
#                               CO2 - Mauna Loa 
#          ( see: https://www.esrl.noaa.gov/gmd/ccgg/trends/data.html )
#
# =========================================================================================== #

import wget
import pandas as pd
import os

# %%
# ========================      Start the Download     ===================================== #


# --- Set the URL
URL_CO2 = "https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_mlo.csv"

# --- Download and store
if os.path.exists(directory + directory_data + "CO2_RawData.csv"):
    os.remove(directory + directory_data + "CO2_RawData.csv")

response = wget.download(URL_CO2, directory + directory_data + "CO2_RawData.csv")

# %%
# ========================      Cleaning the File     ===================================== #

# --- Set the Column-Names
CO2_colnames = ['year','month','decimal date','average','interpolated']

CO2_raw = pd.read_csv(directory + directory_data + "CO2_RawData.csv",
                        skiprows=52, header=None, usecols=list(range(len(CO2_colnames))))

# --- Check that you have correctly extracted the data
assert (CO2_raw.loc[0,0] == 1958) and (CO2_raw.loc[0,1] == 3), 'Something\'s Wrong! Control the Data-Frame'

CO2_raw.columns = CO2_colnames


# %%
# ========================      Overwrite the old file     =========================== #

# -------------- DO NOT TOUCH ----------------- #

start_year = 1978
start_month = 12

# -------------- DO NOT TOUCH ----------------- #

# --- Extract the relevant time series
idx = CO2_raw.loc[(CO2_raw.year == start_year) & (CO2_raw.month == start_month),:].index[0]
CO2_out = CO2_raw.loc[idx:,['year','month','interpolated']]

# --- Rename columns
CO2_out.columns = ['Year','Month','CO2']


# --- Export 
CO2_out.to_csv(directory + '/10_data/CO2_monthly.csv', index=False)



# %%
# =========================================================================================== #
#
#                               Sea Ice Thickness - PIOMAS 
#          ( see: http://psc.apl.uw.edu/wordpress/wp-content/uploads/schweiger/ice_volume/PIOMAS.thick.daily.1979.2021.Current.v2.1.dat.gz )
#
# =========================================================================================== #

import wget
import pandas as pd
from datetime import datetime
import os

# %%
# ========================      Start the Download     ===================================== #

# --- Set the URL
current_year = str(datetime.now().year)
URL_SIT = "http://psc.apl.uw.edu/wordpress/wp-content/uploads/schweiger/ice_volume/PIOMAS.thick.daily.1979." + current_year + ".Current.v2.1.dat.gz"

# --- Download and store
if os.path.exists(directory + directory_data + "SIT_RawData.dat.gz"):
    os.remove(directory + directory_data + "SIT_RawData.dat.gz")

response = wget.download(URL_SIT, directory + directory_data + "SIT_RawData.dat.gz")

# %%
# --- Unzip & Export as 'csv'
SIT_out = pd.read_csv(directory + directory_data + "SIT_RawData.dat.gz", 
                        compression='gzip', delim_whitespace=True)
SIT_out.columns = ['Year','Year.Day','SIT']

# --- Export 
SIT_out.to_csv(directory + '/10_data/SIT_Daily.csv', index=False)



# %%
# =========================================================================================== #
#
#                               Air Temperature - Berkeley Earth 
#          ( see: http://berkeleyearth.lbl.gov/auto/Global/Land_and_Ocean_complete.txt )
#
# =========================================================================================== #

import wget
import pandas as pd
import numpy as np
import os

# %%
# ========================      Start the Download     ===================================== #

# --- Set the URL
URL_AT = "http://berkeleyearth.lbl.gov/auto/Global/Land_and_Ocean_complete.txt"

# --- Download and store
if os.path.exists(directory + directory_data + "AT_RawData.csv"):
    os.remove(directory + directory_data + "AT_RawData.csv")

response = wget.download(URL_AT, directory + directory_data + "AT_RawData.csv")

# %%
# ========================      Cleaning the File     ===================================== #

# --- Set the Column-Names
AT_colnames = ['Year','Month','AT']

AT_raw = pd.read_csv(directory + directory_data + "AT_RawData.csv",
                        skiprows=85, header=None, usecols=list(range(len(AT_colnames))),
                        delim_whitespace=True)

idx = AT_raw.loc[(AT_raw.loc[:,0] == '1850') & (AT_raw.loc[:,1] == '1'),:].index[1]

# ---- Since the data file contains (I) AT with Sea Ice Temperature derived from Air Temperature & (II) AT with Sea Ice Temperature derived from Sea Temperature,
# ---- ---> only take (I)
AT_raw = AT_raw.loc[:(idx-5),:].astype(float)

# --- Check that you have correctly extracted the data
assert (AT_raw.loc[0,0] == 1850) and (AT_raw.loc[0,1] == 1), 'Something\'s Wrong! Control the Data-Frame'

AT_raw.columns = AT_colnames

# %%
# ========================      Overwrite the old file     =========================== #

# -------------- DO NOT TOUCH ----------------- #

start_year = 1978
start_month = 12

# -------------- DO NOT TOUCH ----------------- #

# --- Extract the relevant time series
idx = AT_raw.loc[(AT_raw.Year == start_year) & (AT_raw.Month == start_month),:].index[0]
AT_out = AT_raw.loc[idx:,AT_colnames].reset_index()

# --- Add "2022" as NaNs
add_2022 = pd.DataFrame({'Year':np.ones((12,))*2022,
                         'Month':range(1,13),
                         "AT": np.empty(12).fill(np.nan)})

AT_out = pd.concat([AT_out,add_2022], axis=0, ignore_index=True).drop(columns="index")


# --- Export 
AT_out.to_csv(directory + '/10_data/AT_monthly.csv', index=False)


