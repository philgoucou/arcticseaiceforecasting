h002_rhscomponents <- function(r, month.day.index, mon,
                               help_df, 
                               list.vars,
                               I.want.trend, I.want.trendQ, 
                               I.want.summerD, I.want.winterD, monthlyD){
  
  #   Create the Formula for the regression
  today.day <- month.day.index$day[which(month.day.index$month == as.character(help_df$This.Month[r]) & 
                                           month.day.index$day == help_df$Day.This.Month[r])]
  today.month <- as.character(month.day.index$month[which(month.day.index$month == as.character(help_df$This.Month[r]) 
                                                          & month.day.index$day == help_df$Day.This.Month[r])])
  row.today <- which(month.day.index$month == today.month & month.day.index$day == today.day)
  
  #   Shift the month-vector, such that "today.month" is at position 12
  if (today.month == "sDEC"){
    mon.t <- mon[-(which(mon == today.month))]
    mon.t1 <- c()
  } else if (today.month == "sJAN"){
    mon.t <- c()
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  } else  {
    mon.t <- mon[1:(which(mon == today.month) - 1)]
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  }
  mon.shifted <- c(mon.t1, mon.t, today.month)
  
  #   -------- BUILD THE FORMULA!    --------------------------------------------------------------------------        
  
  #   "singledays.lag"
  single.days <- ""
  single.days.vec <- NA
  for (xx in 1:length(list.vars)){
    if (length(list.vars[[xx]][["singledays.lag"]]) > 0){
      for (ll in 1:length(list.vars[[xx]][["singledays.lag"]])){
        
        # Does some data have to be shifted backwards, due to publication lag?
        if (names(list.vars[xx]) == "SII"){
          row.today_xx <- row.today
        } else if (names(list.vars[xx]) == "SIT"){
          today.month.lag <- mon.shifted[which(mon.shifted == today.month) - 2]
          today.month.lag.lastday <- max(month.day.index$day[which(month.day.index$month == today.month.lag)])
          
          row.today_xx <- which(month.day.index$month == as.character(today.month.lag) & 
                               month.day.index$day == as.character(today.month.lag.lastday)) 
        }
        
        
        month.name.raw <- month.day.index$month[row.today_xx - list.vars[[xx]][["singledays.lag"]][ll]]
        month.name.raw <- substr(month.name.raw,2,4)
        
        single.days <- paste0(single.days, "s", list.vars[[xx]][["prefix"]],
                              month.name.raw, 
                              month.day.index$day[row.today_xx - list.vars[[xx]][["singledays.lag"]][ll]], "_", 
                              month.day.index$day[row.today_xx - list.vars[[xx]][["singledays.lag"]][ll]], " + ")
        single.days.vec[length(single.days.vec) + 1] <- paste0("s", list.vars[[xx]][["prefix"]],
                                                               month.name.raw, 
                                                               month.day.index$day[row.today_xx - list.vars[[xx]][["singledays.lag"]][ll]], "_", 
                                                               month.day.index$day[row.today_xx - list.vars[[xx]][["singledays.lag"]][ll]])
      }
      single.days.vec <- na.omit(single.days.vec)
    }
  }
  #   Get rid of the last " + "
  single.days <- substr(single.days,1,nchar(single.days) - 3)
  
  #   "singlemonths.lag"
  single.months <- ""
  single.months.vec <- NA
  for (xx in 1:length(list.vars)){
    if (length(list.vars[[xx]][["singlemonths.lag"]]) > 0){
      for (ll in 1:length(list.vars[[xx]][["singlemonths.lag"]])){
        
        # Does some data have to be shifted backwards, due to publication lag?
        if (names(list.vars[xx]) == "SII"){
          today.month_xx <- today.month
        } else if (names(list.vars[xx]) %in% c("SIT")){
          today.month.lag <- mon.shifted[which(mon.shifted == today.month) - 1]
          today.month_xx <- today.month.lag
        } else if (names(list.vars[xx]) %in% c("CO2")){
          today.month.lag <- mon.shifted[which(mon.shifted == today.month) - 2]
          today.month_xx <- today.month.lag
        } else if (names(list.vars[xx]) %in% c("AT")){
          today.month.lag <- mon.shifted[which(mon.shifted == today.month) - 3]
          today.month_xx <- today.month.lag
        }
        
        month.name.raw <- mon.shifted[which(mon.shifted == today.month_xx) - 1 - list.vars[[xx]][["singlemonths.lag"]][ll]]
        month.name.raw <- substr(month.name.raw,2,4)
        
        single.months <- paste0(single.months, "s", list.vars[[xx]][["prefix"]],month.name.raw, " + ")
        single.months.vec[length(single.months.vec) + 1] <- paste0("s", list.vars[[xx]][["prefix"]],month.name.raw)
      }
      single.months.vec <- na.omit(single.months.vec)
    }
    
  # Next "xx"
  }
  #   Get rid of the last " + "
  single.months <- substr(single.months,1,nchar(single.months) - 3)
  
  #   "Days_XX.XX"
  Days_XX.XX <- c()
  days <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  days.in_today.month <- days[which(mon == today.month)]
  
  for (xx in 1:length(list.vars)){
    
    list.vars.xx <- list.vars[[xx]]
    
    diff.days.xx <- list.vars.xx[["XX.Days.start"]]-list.vars.xx[["XX.Days.end"]]
    if (today.day == days.in_today.month & any(diff.days.xx == days.in_today.month)){
      pos.remove <- which(list.vars.xx[["XX.Days.start"]]-list.vars.xx[["XX.Days.end"]] == days.in_today.month)
      list.vars.xx[["XX.Days.start"]] <- list.vars.xx[["XX.Days.start"]][-pos.remove]
      list.vars.xx[["XX.Days.end"]] <- list.vars.xx[["XX.Days.end"]][-pos.remove]
      
      #   Add the whole month to "single.months" & "single.months.vec"
      single.months <- paste0(single.months, " + s", list.vars.xx[["prefix"]],substr(today.month,2,nchar(today.month)))
      single.months.vec[length(single.months.vec) + 1] <- paste0("s", list.vars.xx[["prefix"]],
                                                                 substr(today.month,2,nchar(today.month)))
    } else if (today.day == days.in_today.month & !any(diff.days.xx == days.in_today.month)){
      
      #   Add the whole month to "single.months" & "single.months.vec"
      single.months <- paste0(single.months, " + s", list.vars.xx[["prefix"]],substr(today.month,2,nchar(today.month)))
      single.months.vec[length(single.months.vec) + 1] <- paste0("s", list.vars.xx[["prefix"]],
                                                                 substr(today.month,2,nchar(today.month)))
    }
    XX.length <- min(length(list.vars.xx[["XX.Days.start"]]),length(list.vars.xx[["XX.Days.end"]]))
    if (XX.length > 0){
      Days_XX.XX <- paste0(Days_XX.XX, 
                           paste0(list.vars.xx[["prefix"]],"Days_",
                                  list.vars.xx[["XX.Days.start"]][1:XX.length],".",
                                  list.vars.xx[["XX.Days.end"]][1:XX.length], collapse = " + "), " + ")
    }
  }
  #   Get rid of the last " + "
  Days_XX.XX <- substr(Days_XX.XX,1,nchar(Days_XX.XX) - 3)
  
  Xparty <- paste(c(" c", single.days, single.months, Days_XX.XX), collapse = " + ")
  
  #   Trends & Dummies
  if (I.want.trend == "yes"){
    Xparty <- paste0(Xparty, " + trend")
  }
  if (I.want.trendQ == "yes"){
    Xparty <- paste0(Xparty, " + trendQ")
  }
  if (I.want.summerD == "yes"){
    Xparty <- paste0(Xparty, " + summer")
  }
  if (I.want.winterD == "yes"){
    Xparty <- paste0(Xparty, " + winter")
  }
  if (length(monthlyD) > 0){
    Xparty <- paste0(Xparty, " + " ,paste0("D", monthlyD, collapse = " + " ))
  }
  
  output <- list(single.days.vec, single.months.vec, Days_XX.XX, Xparty, today.month,mon.shifted)
  names(output) <- c("single.days.vec", "single.months.vec", "Days_XX.XX", "Xparty","today.month","mon.shifted")
  
  return(output)
  
}