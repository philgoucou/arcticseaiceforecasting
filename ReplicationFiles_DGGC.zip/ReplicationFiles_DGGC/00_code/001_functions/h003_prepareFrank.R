h003_prepareFrank <- function(directory, prep.data, I.want.realobs, I.want.subset.of.syn.months, r, m.star,
                                include.quadratic){
  
  ######################################################################################################################
  #
  #   As of now (03/25/2021): Frank's model runs with an "m.star-dummy" on the whole synthetic data set
  #                           ---> there is the option to let Frank's model run only on "real observations", regardless
  #                                whether the "ML-Algos" run on synthetic data or not
  #
  ######################################################################################################################

  
  #   Function-Calls for preparing the data-set
  source(file.path(directory,"00_code/001_functions/h201_prepdata.R"))
  source(file.path(directory,"00_code/001_functions/h201_rhscomponents.R"))
  source(file.path(directory,"00_code/001_functions/h201_buildxparty.R"))
  
  prep.data.Frank <- h201_prepdata(directory, m.star, XX.Days.start=c(30), XX.Days.end=c(0))
  
  #   Manipulate "prep.data.Frank" for it to only include data from Sea Ice Index
  #   Load the syntehtic data

  #   If you want to only include real observations:
  if (I.want.realobs =="yes"){
    real.obs <- read.csv(file.path(directory,paste0("10_data/SII_processed_nomissing_realobs.csv")))
    colnames(real.obs) <- c("Year", paste0("s",colnames(real.obs)[2:ncol(real.obs)]))
    
    add.df <- data.frame("trend" = seq(1,nrow(real.obs)), "month" = NA ,"summer" = NA, "winter" = NA)
    add.df[, paste0("D",c(1:12))] <- NA
    
    prep.data.Frank$SII_data <- cbind(real.obs, add.df)
    prep.data.Frank$SII_data.true <- prep.data.Frank$SII_data
    
  } 
  
  
  
  
  #   Now create components, necessary for the regression model:
  #       I)    "single.days.vec":      A vector containing all the single-day-regressors
  #       II)   "single.months.vec":    A vector containing all the single-month-regressors
  #       III)  "Days_XX.XX":           A string containing the "averages" across days 
  #       IV)   "Xparty":               A string containing your regression formula
  rhs.components.Frank <- h201_rhscomponents(r = r, month.day.index=prep.data.Frank$month.day.index, 
                                             mon = prep.data.Frank$mon,
                                             help_df=prep.data.Frank$help_df, 
                                             singledays.lag=c(0), singlemonths.lag=c(0),
                                             XX.Days.start=c(30), XX.Days.end=c(0), 
                                             I.want.trend="yes", I.want.trendQ=include.quadratic, 
                                             I.want.summerD="no", I.want.winterD="no", 
                                             monthlyD=c())
  
  #   Now build your "Xparty", i.e. the data for the RHS of your model 
  Frank.Xparty.df <- h201_buildxparty(m.star=m.star,mon=prep.data.Frank$mon, today.month = rhs.components.Frank$today.month,
                                      SII_data=prep.data.Frank$SII_data,
                                      single.days.vec=rhs.components.Frank$single.days.vec,
                                      single.months.vec=rhs.components.Frank$single.months.vec,
                                      list_XX.XX=prep.data.Frank$list_XX.XX, 
                                      Days_XX.XX=rhs.components.Frank$Days_XX.XX,
                                      I.want.trend="yes", I.want.trendQ=include.quadratic, 
                                      I.want.summerD="no", I.want.winterD="no", 
                                      monthlyD=c(), I.want.realobs,I.want.subset.of.syn.months)
  
  #   Store the regressor-names of Frank's model, (without dummies!)
  Franks.regressors <- colnames(Frank.Xparty.df)[4:ncol(Frank.Xparty.df)]
  
  # If you have chosen "synthetic data": interact "Frank.Xparty.df[,4:ncol(Frank.Xparty.df)]" with 
  # each of the dummies (D[1:12])
  if (!(I.want.realobs == "yes")){
    #dummy_m.star <- prep.data.Frank$SII_data.true[,paste0("D",which(prep.data.Frank$mon == m.star))]
    #Frank.Xparty.df[,4:ncol(Frank.Xparty.df)] <- Frank.Xparty.df[,4:ncol(Frank.Xparty.df)] * dummy_m.star
    #Frank.Xparty.df$trend <- Frank.Xparty.df$trend / 12
    
    # How many interaction-terms do you need?
    if (length(I.want.subset.of.syn.months) > 0){
      I.need.interactions <- I.want.subset.of.syn.months
    } else{
      I.need.interactions <- c(1:12)
    }
    
    
    Frank.Xparty.df_nodummies <- Frank.Xparty.df
    Frank.Xparty.df <- data.frame(matrix(NA, nrow = nrow(Frank.Xparty.df_nodummies), ncol=4*length(I.need.interactions),
                                         dimnames = list(c(),c(paste0("D", rep(I.need.interactions, each = 4), ".",
                                                               colnames(Frank.Xparty.df_nodummies[4:ncol(Frank.Xparty.df_nodummies)]))))))
    Frank.Xparty.df <- cbind(Frank.Xparty.df_nodummies[,1:3],Frank.Xparty.df)
    
    #   Extract the monthly-dummys.df from the "SII_data.true"
    if (length(I.want.subset.of.syn.months) > 0){
      #   Throw out rows which are not in "I.want.subset.of.syn.months"
      dummys.df <- prep.data.Frank$SII_data.true[which(prep.data.Frank$SII_data.true$month %in% I.want.subset.of.syn.months), 
                                                 paste0("D",c(1:12))]
    } else{
      dummys.df <- prep.data.Frank$SII_data.true[, paste0("D",c(1:12))]
    }
    
    for (dd in I.need.interactions){
      dd.colnames <- paste0("D", dd, ".", colnames(Frank.Xparty.df_nodummies[4:ncol(Frank.Xparty.df_nodummies)]))
      orig.regressors <- colnames(Frank.Xparty.df_nodummies[4:ncol(Frank.Xparty.df_nodummies)])
      
      Frank.Xparty.df[,dd.colnames] <- Frank.Xparty.df_nodummies[,orig.regressors] * dummys.df[,paste0("D",dd)] 
    }
    
    #   Reformulate the formula ("Xparty") in "rhs.components.Frank"
    rhs.components.Frank$Xparty <- paste0(colnames(Frank.Xparty.df[,4:ncol(Frank.Xparty.df)]), collapse = " + ")
    
  } else{
    Frank.Xparty.df_nodummies <- NA
  }
  
  # Define Frank's 'X'
  X.Frank <- as.matrix(Frank.Xparty.df[which(Frank.Xparty.df$Year %in% train.years),4:ncol(Frank.Xparty.df)])
  
  # Define Frank's 'Y'
  if (length(I.want.subset.of.syn.months) > 0){
    Y.Frank <- as.matrix(data.frame("Y" = prep.data.Frank$SII_data[which(prep.data.Frank$SII_data$Year %in% train.years &
                                                            prep.data.Frank$SII_data$month %in% I.want.subset.of.syn.months),
                                                                   m.star]))
  } else{
    Y.Frank <- as.matrix(data.frame("Y" = prep.data.Frank$SII_data[which(prep.data.Frank$SII_data$Year %in% train.years),
                                                                   m.star]))
  }
  
  # Define Frank's 'Xtest' ---> do not include the constant!
  Xtest.Frank <- as.matrix(Frank.Xparty.df[which(Frank.Xparty.df$Year %in% test.years),4:ncol(Frank.Xparty.df)])
  
  # Define Frank's 'Ytest'
  if (length(I.want.subset.of.syn.months) > 0){
    Ytest.Frank <- as.matrix(data.frame("Y" = prep.data.Frank$SII_data[which(prep.data.Frank$SII_data$Year %in% test.years &
                                                            prep.data.Frank$SII_data$month %in% I.want.subset.of.syn.months),
                                                                   m.star]))
  } else{
    Ytest.Frank <- as.matrix(data.frame("Y" = prep.data.Frank$SII_data[which(prep.data.Frank$SII_data$Year %in% test.years),
                                                                     m.star]))
  }
  
  # Define Frank's regression-formula
  reg.form.Frank <- paste0("Y ~ ", rhs.components.Frank$Xparty)
  
  datin.Frank = cbind(Y.Frank,X.Frank) #[-c(1:12),]
  datin.Frank=datin.Frank[complete.cases(datin.Frank),]
  Y.Frank=datin.Frank[,1]
  X.Frank=datin.Frank[,-c(1)]
  
  output <- list(prep.data.Frank, rhs.components.Frank, Frank.Xparty.df, Frank.Xparty.df_nodummies,
                 X.Frank, Y.Frank, Xtest.Frank, Ytest.Frank, datin.Frank,Franks.regressors)
  names(output) <- c("prep.data.Frank", "rhs.components.Frank", "Frank.Xparty.df", "Frank.Xparty.df_nodummies",
                     "X.Frank", "Y.Frank", "Xtest.Frank", "Ytest.Frank", "datin.Frank","Franks.regressors")
  
  return(output)
}