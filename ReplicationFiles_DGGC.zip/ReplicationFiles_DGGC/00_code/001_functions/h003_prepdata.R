h003_prepdata <- function(directory, m.star, I.want.vars, list.vars, I.want.FD){
  
  mon <- c("sJAN", "sFEB", "sMAR", "sAPR", "sMAY", "sJUN", "sJUL", "sAUG", "sSEP", "sOCT", "sNOV", "sDEC")
  mon.freeze <- mon  
  days <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  
  ICE_data <- read.csv(file = file.path(directory, 
                                        paste0("10_data/SyntheticData/SII_SyntheticPanel_",substr(m.star,2,4),".csv")))
  ICE_data <- as.matrix(ICE_data[,1])
  colnames(ICE_data) <- "Year"
  
  #   Import the monthly-daily synthetic data
  if ("SII" %in% I.want.vars){
    SII_data <- read.csv(file = file.path(directory, 
                                        paste0("10_data/SyntheticData/SII_SyntheticPanel_",substr(m.star,2,4),".csv")))
    ICE_data <- cbind(ICE_data,SII_data[,2:ncol(SII_data)])
  }
  if ("SIT" %in% I.want.vars){
    SIT_data <- read.csv(file = file.path(directory, 
                                          paste0("10_data/SyntheticData/SIT_SyntheticPanel_",substr(m.star,2,4),".csv")))
    ICE_data <- cbind(ICE_data,SIT_data[,2:ncol(SIT_data)])
  }
  if ("CO2" %in% I.want.vars){
    if (I.want.FD$CO2 == "yes"){
      CO2_data <- read.csv(file = file.path(directory, 
                                            paste0("10_data/SyntheticData/CO2_SyntheticPanel_",substr(m.star,2,4),"_FD.csv")))
    } else {
      CO2_data <- read.csv(file = file.path(directory, 
                                            paste0("10_data/SyntheticData/CO2_SyntheticPanel_",substr(m.star,2,4),".csv")))
    }
    ICE_data <- cbind(ICE_data,CO2_data[,2:ncol(CO2_data)])
  }
  if ("AT" %in% I.want.vars){
    if (I.want.FD$AT == "yes"){
      AT_data <- read.csv(file = file.path(directory, 
                                            paste0("10_data/SyntheticData/AT_SyntheticPanel_",substr(m.star,2,4),"_FD.csv")))
    } else {
      AT_data <- read.csv(file = file.path(directory, 
                                            paste0("10_data/SyntheticData/AT_SyntheticPanel_",substr(m.star,2,4),".csv")))
    }
    ICE_data <- cbind(ICE_data,AT_data[,2:ncol(AT_data)])
  }
  
  #   Assign the time-trend
  time <- data.frame("year" = ICE_data$Year,"month" = rep(1:12,times = length(unique(ICE_data$Year))))
  ICE_data$trend <- seq(1,nrow(ICE_data), by = 1)
  
  #   Assign Monthly-Indicators ---> BEWARE:  the dummies will be anchored @ "m.star" (your Y-Variable)
  #                             --->          i.e. if "m.star==SEP", ICE_data[1:12,month] = c(10,11,12,1,2,3,4,5,6,7,8,9)
  #                             --->          because the "real" observation for "m.star" sits at the LAST data-point 
  #                                           in each year
  if (m.star == "sDEC"){
    mon.ind <- seq(1,12, by = 1)
  } else if (m.star == "sJAN"){
    mon.ind <- c(seq(2,12, by = 1),1)
  } else  {
    mon.ind <- c(seq(which(mon == m.star) + 1,length(mon), by = 1), 
                 seq(1,which(mon == m.star) - 1, by = 1), 
                 which(mon == m.star))
  }
  ICE_data$month <- rep(mon.ind, times = length(unique(ICE_data$Year)))
  
  #   Assign Summer-Winter dummies ---> summer == JUN-SEP; winter == NOV-MAR
  ICE_data$summer <- 0
  ICE_data$summer[which(ICE_data$month %in% c(6,7,8,9))] <- 1
  ICE_data$winter <- 0
  ICE_data$winter[which(ICE_data$month %in% c(1,2,3,11,12))] <- 1
  
  #   Assign monthly-dummies: "D[NUMBER]"
  for (mm in mon){
    mm.colname <- paste0("D",which(mon == mm))
    ICE_data[,mm.colname] <- 0
    ICE_data[which(ICE_data$month == which(mon == mm)),mm.colname] <- 1
  }
  
  
  #   Freeze a copy of the dataset
  ICE_data.true <- ICE_data
  
  
  
  # If m.star == JAN | FEB | MAR | APR --> reshuffle!
  #if (m.star == "sJAN" | m.star == "sFEB" | m.star == "sMAR" | m.star == "sAPR"){
    mon.idx <- 1:which(mon == m.star)
    mon.names <- mon[mon.idx]
    
    mon <- mon[-mon.idx]
    mon <- c(mon, mon.names)
    
    days.number <- days[mon.idx]
    days <- days[-mon.idx]
    days <- c(days, days.number)
    
  #}
  
  #   Create a month-day index to ease the identification of "Last.XX.Days"
  month.day.index <- data.frame("month" = rep(mon, days))
  for (mm in mon){
    month.day.index[which(month.day.index$month == mm), "day"] <- rep(1:days[which(mon == mm)])
  }
  
  #   Set-up a data-frame: Column = RMSE; Rows = Sum(days in month (m.star-3), days in month (m.star-2), days in month (m.star-1), days in month (m.star))
  glide.chart <- data.frame(matrix(NA, nrow = sum(days[(which(mon == m.star) - 3):which(mon == m.star)]),
                                   ncol = 4, dimnames = list(c(c(paste0("(M*-3).", c(1:days[(which(mon == m.star) - 3)])),
                                                                 paste0("(M*-2).", c(1:days[(which(mon == m.star) - 2)])),
                                                                 paste0("(M*-1).", c(1:days[(which(mon == m.star) - 1)])),
                                                                 paste0("(M*).", c(1:days[(which(mon == m.star))])))),
                                                             c("Point", "SE2_up", "SE2_low","formula"))))
  
  
  #   Set-up a helping data-frame: Columns: Last.Month, This.Month, Day.This.Month
  help_df <- data.frame("Last.Month" = c(rep(mon[which(mon == m.star) - 4], times = days[(which(mon == m.star) - 3)]),
                                         rep(mon[which(mon == m.star) - 3], times = days[(which(mon == m.star) - 2)]),
                                         rep(mon[which(mon == m.star) - 2], times = days[(which(mon == m.star) - 1)]),
                                         rep(mon[which(mon == m.star) - 1], times = days[(which(mon == m.star) - 0)])),
                        "This.Month" = c(rep(mon[which(mon == m.star) - 3], times = days[(which(mon == m.star) - 3)]),
                                         rep(mon[which(mon == m.star) - 2], times = days[(which(mon == m.star) - 2)]),
                                         rep(mon[which(mon == m.star) - 1], times = days[(which(mon == m.star) - 1)]),
                                         rep(mon[which(mon == m.star) - 0], times = days[(which(mon == m.star) - 0)])),
                        "Day.This.Month" = c(1:days[(which(mon == m.star) - 3)],
                                             1:days[(which(mon == m.star) - 2)],
                                             1:days[(which(mon == m.star) - 1)],
                                             1:days[(which(mon == m.star) - 0)]))
  
  help_df$Last.Month <- c(as.character(help_df$Last.Month[2:nrow(help_df)]), m.star)
  
  #   Identify the "Days_XX.XX" ---> make a list of length "min(length(XX.Days.start),length(XX.Days.end))"
  list_XX.XX <- rep(list(NA), times = length(I.want.vars))
  names(list_XX.XX) <- I.want.vars
  
  for (xx in 1:length(list.vars)){
    
    list_XX.XX_xx <- rep(list(NA),min(length(list.vars[[xx]][["XX.Days.start"]]),length(list.vars[[xx]][["XX.Days.end"]])))
    if (length(list_XX.XX_xx) > 0){
      for (ll in 1:length(list_XX.XX_xx)){
        help_df.ll <- help_df
        for (dd in 1:nrow(help_df.ll)){
          
          # Does some data have to be shifted backwards, due to publication lag?
          if (names(list.vars[xx]) == "SII"){
            today.row <- which(month.day.index$month == as.character(help_df.ll$This.Month[dd]) & 
                                 month.day.index$day == help_df.ll$Day.This.Month[dd]) 
          } else if (names(list.vars[xx]) == "SIT"){
            today.month <- as.character(help_df.ll$This.Month[dd])
            today.month.lag <- mon[which(mon == today.month) - 2]
            today.month.lag.lastday <- max(month.day.index$day[which(month.day.index$month == today.month.lag)])
            
            today.row <- which(month.day.index$month == as.character(today.month.lag) & 
                                 month.day.index$day == as.character(today.month.lag.lastday)) 
          }
          
          
          month.name.raw_start <- month.day.index$month[today.row - (list.vars[[xx]][["XX.Days.start"]][ll] - 1)]
          month.name.raw_start <- substr(month.name.raw_start,2,4)
          
          
          # Determine the beginning of the XX-day-period
          help_df.ll[dd, "XX.Days.START"] <- NA
          help_df.ll$XX.Days.START[dd] <- paste0("s", list.vars[[xx]][["prefix"]], month.name.raw_start,
                                                 month.day.index$day[today.row - (list.vars[[xx]][["XX.Days.start"]][ll] - 1)],
                                                 "_", month.day.index$day[today.row - (list.vars[[xx]][["XX.Days.start"]][ll] - 1)])
          # Determine middle-part of the XX-day-period
          XX.interval <- list.vars[[xx]][["XX.Days.start"]][ll] - list.vars[[xx]][["XX.Days.end"]][ll]
          for (m in (list.vars[[xx]][["XX.Days.start"]][ll] - 2):(list.vars[[xx]][["XX.Days.end"]][ll] + 1)){
            help_df.ll[dd, paste0("XX.Days.START", (XX.interval-m))] <- NA
            
            month.name.raw_m <- month.day.index$month[today.row - m]
            month.name.raw_m <- substr(month.name.raw_m,2,4)
            
            help_df.ll[dd, paste0("XX.Days.START", (XX.interval-m))] <- paste0("s", list.vars[[xx]][["prefix"]], 
                                                                               month.name.raw_m, 
                                                                               month.day.index$day[today.row - m],
                                                                               "_", month.day.index$day[today.row - m])
          }
          
          # Determine the end of the XX-day-period
          help_df.ll[dd, "XX.Days.END"] <- NA
          
          month.name.raw_end <- month.day.index$month[today.row - list.vars[[xx]][["XX.Days.end"]][ll]]
          month.name.raw_end <- substr(month.name.raw_end,2,4)
          
          help_df.ll$XX.Days.END[dd] <- paste0("s", list.vars[[xx]][["prefix"]], 
                                               month.name.raw_end, 
                                               month.day.index$day[today.row - list.vars[[xx]][["XX.Days.end"]][ll]],"_", 
                                               month.day.index$day[today.row - list.vars[[xx]][["XX.Days.end"]][ll]])
        }
        list_XX.XX_xx[[ll]] <- help_df.ll
        names(list_XX.XX_xx)[ll] <- paste0(list.vars[[xx]][["prefix"]],"Days_",
                          list.vars[[xx]][["XX.Days.start"]][ll],".",
                          list.vars[[xx]][["XX.Days.end"]][ll])
      } #This ends: for (ll in 1:length(list_XX.XX)){
    } # This ends: if (length(list_XX.XX) > 0){
    
    list_XX.XX[[xx]] <- list_XX.XX_xx

  # Next "xx"
  }
  #   Use the previously frozen data-frame to re-set your working-dataframe
  ICE_data <- ICE_data.true
  
  
  # Store the daily densities in a list
  sample.range <- 10^7
  densities.daily <- data.frame(matrix(NA, nrow = nrow(glide.chart), ncol = 2, dimnames = list(c(),c("mean","se"))))
  
  output <- list(ICE_data, ICE_data.true, glide.chart, help_df, list_XX.XX, densities.daily, 
                 month.day.index, mon.freeze)
  names(output) <- c("ICE_data", "ICE_data.true", "glide.chart", "help_df", "list_XX.XX", "densities.daily",
                     "month.day.index", "mon")
  
  return(output)
  
}