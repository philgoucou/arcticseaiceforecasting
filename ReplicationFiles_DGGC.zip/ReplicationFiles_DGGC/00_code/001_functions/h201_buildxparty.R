h201_buildxparty <- function(m.star,mon, today.month,
                             SII_data,single.days.vec,single.months.vec,
                              list_XX.XX, Days_XX.XX,
                              I.want.trend, I.want.trendQ,
                              I.want.summerD, I.want.winterD,
                              monthlyD,I.want.realobs,I.want.subset.of.syn.months) {
  
  # Are there any regressors that need to be shifted by a year?
  # --->    If "today.month == JUN" and one of the regressors is in "c("JUL","AUG","SEP","OCT","NOV","DEC")", 
  #         we need to shift them by one year (== 12 rows)
  if (FALSE){
  if (today.month == "sDEC"){
    if (m.star == "sDEC"){
      mon.t <- mon[-(which(mon == today.month))]
      mon.t1 <- c()
      mon.t2 <- c()
    } else if (m.star == "sJAN"){
      mon.t <- c()
      mon.t1 <- mon[1:(which(mon == today.month) - 1)]
      mon.t2 <- c()
    } else {
      mon.t <- c()
      mon.t1 <- mon
      mon.t2 <- c()
    }
  } else if (today.month == "sJAN"){
    mon.t <- c()
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
    mon.t2 <- c()
  } else  {
    if (m.star %in% c("sJAN","sFEB","sMAR","sAPR")){
      if (today.month == "sJAN" & m.star == "sJAN"){
        mon.t <- c()
        mon.t1 <- mon[1:(which(mon == today.month) - 1)]
        mon.t2 <- mon[min(which(mon == today.month) + 1,length(mon)):length(mon)]
      } else {
        mon.t <- c("sJAN","sFEB","sMAR","sAPR")[1:which(c("sJAN","sFEB","sMAR","sAPR") == m.star)]
        mon.t1 <- mon[(which(mon == m.star) + 1):(which(mon == today.month) - 1)]
        mon.t2 <- c()
      }
    } else {
      mon.t <- mon[1:(which(mon == today.month) - 1)]
      mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
      mon.t2 <- c()
    }
  }
  }
  
  pos.today.month <- which(mon == today.month)
  pos.m.star <- which(mon == m.star)
  
  if (pos.today.month > pos.m.star){
    if (pos.today.month %in% c(9,10,11,12) & pos.m.star %in% c(1,2,3,4)){
      mon.t <- c()
      mon.t1 <- mon[1:(which(mon == today.month))]
      if (pos.today.month == 12){mon.t2 <- c()}else{mon.t2 <- mon[min(which(mon == today.month)+1,length(mon)):length(mon)]}
    } else {
      mon.t <- mon[1:(which(mon == today.month) - 1)]
      mon.t1 <- mon[min(which(mon == today.month) + 1,length(mon)):length(mon)]
      mon.t2 <- c()
    }
  } else {
    if (pos.today.month > 1){mon.t <- mon[1:(pos.today.month-1)]}else{mon.t <- c()}
    if (pos.today.month == 12){mon.t1 <- c()}else{mon.t1 <- mon[min(which(mon == today.month)+1,length(mon)):length(mon)]}
    mon.t2 <- c()
  }
      
  Xparty.df <- data.frame("Year" =  SII_data$Year,"c" = rep(1, times= length(SII_data$Year)),
                          "month" = SII_data$month)
  
  # I)    "single.days"
  if (length(single.days.vec) > 0){
    single.days.df <- data.frame(matrix(NA,nrow=nrow(SII_data),ncol=length(single.days.vec),
                                        dimnames = list(c(),single.days.vec)))
    for (ll in 1:length(single.days.vec)){
      month.ll <- substr(single.days.vec[ll],1,4)
      
      # Shift the series "single.days.vec[ll]" if it is among "mon.t1"
      if (month.ll %in% mon.t1){
        if (I.want.realobs == "yes"){
          single.days.df[,single.days.vec[ll]] <- c(NA, SII_data[1:(nrow(SII_data)-1),single.days.vec[ll]])
        } else{
          single.days.df[,single.days.vec[ll]] <- c(rep(NA,times=12), SII_data[1:(nrow(SII_data)-12),single.days.vec[ll]])
        }
      } else if (month.ll %in% mon.t2){
        if (I.want.realobs == "yes"){
          single.days.df[,single.days.vec[ll]] <- c(NA, NA, SII_data[1:(nrow(SII_data)-2),single.days.vec[ll]])
        } else{
          single.days.df[,single.days.vec[ll]] <- c(rep(NA,times=24), SII_data[1:(nrow(SII_data)-24),single.days.vec[ll]])
        }
      } else {
        single.days.df[,single.days.vec[ll]] <- SII_data[,single.days.vec[ll]]
      }
    }
    Xparty.df <- cbind(Xparty.df, single.days.df)
  }
  
  # II)   "single.months"
  if (length(single.months.vec) > 0){
    single.months.df <- data.frame(matrix(NA,nrow=nrow(SII_data),ncol=length(single.months.vec),
                                          dimnames = list(c(),single.months.vec)))
    for (ll in 1:length(single.months.vec)){
      month.ll <- substr(single.months.vec[ll],1,4)
      
      # Shift the series "single.months.vec[ll]" if it is among "mon.t1"
      if (month.ll %in% mon.t1){
        if (I.want.realobs == "yes"){
          single.months.df[,single.months.vec[ll]] <- c(NA,SII_data[1:(nrow(SII_data)-1),single.months.vec[ll]])
        } else{
          single.months.df[,single.months.vec[ll]] <- c(rep(NA,times=12), 
                                                        SII_data[1:(nrow(SII_data)-12),single.months.vec[ll]])
        }
      } else if (month.ll %in% mon.t2){
        if (I.want.realobs == "yes"){
          single.months.df[,single.months.vec[ll]] <- c(NA,NA,SII_data[1:(nrow(SII_data)-2),single.months.vec[ll]])
        } else{
          single.months.df[,single.months.vec[ll]] <- c(rep(NA,times=24), 
                                                        SII_data[1:(nrow(SII_data)-24),single.months.vec[ll]])
        }
      } else {
        single.months.df[,single.months.vec[ll]] <- SII_data[,single.months.vec[ll]]
      }
    }
    Xparty.df <- cbind(Xparty.df, single.months.df)
  }
  
  # III)    "Days_XX.XX" ---> the average over "Days_XX.XX" when standing at "r"
  if (length(list_XX.XX) > 0 & length(Days_XX.XX) > 0){
    
    #   First, prepare data-frames for each regressor
    
    r_list_XX.XX <- rep(list(NA), length(list_XX.XX))
    #   Run over the number of regressors, i.e. length(Days_XX.XX)
    for (ll in 1:length(r_list_XX.XX)){
      r_df_XX.XX <- data.frame(matrix(NA,nrow=nrow(SII_data),ncol=length(list_XX.XX[[ll]])-3,
                                      dimnames = list(c(),
                                                      as.character(list_XX.XX[[ll]][r,4:length(list_XX.XX[[ll]])]))))
      #   Run over the days over which Days_XX.XX[ll] shall be computed
      for (dd in 1:ncol(r_df_XX.XX)){
        month.dd <- substr(colnames(r_df_XX.XX)[dd],1,4)
        
        # Shift the series "colnames(r_df_XX.XX)[dd]" if it is among "mon.t1"
        if (month.dd %in% mon.t1){
          if (I.want.realobs == "yes"){
            r_df_XX.XX[,colnames(r_df_XX.XX)[dd]] <- c(NA, SII_data[1:(nrow(SII_data)-1),colnames(r_df_XX.XX)[dd]])
          } else{
            r_df_XX.XX[,colnames(r_df_XX.XX)[dd]] <- c(rep(NA,times=12), 
                                                       SII_data[1:(nrow(SII_data)-12),colnames(r_df_XX.XX)[dd]])
          }
          
        } else if (month.dd %in% mon.t2){
          if (I.want.realobs == "yes"){
            r_df_XX.XX[,colnames(r_df_XX.XX)[dd]] <- c(NA,NA, SII_data[1:(nrow(SII_data)-2),colnames(r_df_XX.XX)[dd]])
          } else{
            r_df_XX.XX[,colnames(r_df_XX.XX)[dd]] <- c(rep(NA,times=24), 
                                                       SII_data[1:(nrow(SII_data)-24),colnames(r_df_XX.XX)[dd]])
          }
          
        } else {
          r_df_XX.XX[,colnames(r_df_XX.XX)[dd]] <- SII_data[,colnames(r_df_XX.XX)[dd]]
        }
      } # This ends: for (dd in 1:ncol(r_df_XX.XX)){
      
      r_list_XX.XX[[ll]] <- r_df_XX.XX
      # Build next regressor
    }
    
    #   Second, compute each regressor ----> row-means for each dataframe in the list "r_list_XX.XX"
    names_Days_XX.XX <- unlist(strsplit(Days_XX.XX, " + ", fixed = T))
    Days_XX.XX.df <- data.frame(matrix(NA,nrow=nrow(SII_data),ncol=length(names_Days_XX.XX),
                                       dimnames = list(c(),c(names_Days_XX.XX))))
    for (ll in 1:length(Days_XX.XX.df)){
      Days_XX.XX.df[,ll] <- apply(r_list_XX.XX[[ll]], 1, mean, na.rm = T)
    }
    Days_XX.XX.df[Days_XX.XX.df == "NaN"] <- NA
    
    Xparty.df <- cbind(Xparty.df, Days_XX.XX.df)
    
  }# This ends: if (length(list_XX.XX) > 0){
  
  
  #   IV)     Trends & Dummies
  if (I.want.summerD == "yes"){
    Xparty.df$summer <- SII_data$summer
  }
  if (I.want.winterD == "yes"){
    Xparty.df$winter <- SII_data$winter
  }
  if (length(monthlyD) > 0){
    Xparty.df <- cbind(Xparty.df, SII_data[,paste0("D",monthlyD)])
  }
  if (length(I.want.subset.of.syn.months) > 0){
    Xparty.df <- Xparty.df[which(Xparty.df$month %in% I.want.subset.of.syn.months),]
  }    
  if (I.want.trend == "yes"){
    Xparty.df$trend <- c(1:nrow(Xparty.df))
    #Xparty.df$trend <- SII_data$trend
  }
  if (I.want.trendQ == "yes"){
    Xparty.df$trendQ <- Xparty.df$trend^2
  }

  
    return(Xparty.df)
  
} 