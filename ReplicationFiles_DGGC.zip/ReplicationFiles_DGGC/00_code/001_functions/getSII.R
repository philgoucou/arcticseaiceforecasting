getSII <- function(df, m.star){
  
  
  ################################################################################################
  #
  #      00)  Missing Data Filled with Average of Adjacent Days --- Create a STACKED SII-Dataframe
  #
  ################################################################################################
  {
    mon <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
    daily.colnames <- c()
    
    for (m in mon){
      if (m %in% c("JAN", "MAR", "MAY", "JUL", "AUG", "OCT", "DEC")){
        daily.colnames <- c(daily.colnames, paste0(m, c(1:31),"_", c(1:31)))
      } else if (m %in% c("APR", "JUN", "SEP", "NOV")){
        daily.colnames <- c(daily.colnames, paste0(m, c(1:30),"_", c(1:30)))
      } else if (m == "FEB"){
        daily.colnames <- c(daily.colnames, paste0(m, c(1:28),"_",c(1:28)))
      }
    }
    
  }
  df_daily_stacked <- data.frame("Year" = rep(1979:df$Year[nrow(df)], each = 365),
                                  "help" = rep(daily.colnames, times = df$Year[nrow(df)] - 1979 + 1))
  
  {
    
    for (r in 1:nrow(df_daily_stacked)){
      df_daily_stacked[r,"Month"] <- which(mon == substr(df_daily_stacked$help[r],1,3))
      df_daily_stacked[r,"Day"] <- as.numeric(substr(df_daily_stacked$help[r],
                                                      gregexpr(pattern ='_', df_daily_stacked$help[r])[[1]][1] + 1,
                                                      nchar(as.character(df_daily_stacked$help[r]))))
    }
    df_daily_stacked <- df_daily_stacked[,c("Year", "Month", "Day")]
    for (r in 1:nrow(df)){
      
      find.row <- which(df_daily_stacked$Year == df$Year[r] &
                          df_daily_stacked$Month == df$Month[r] &
                          df_daily_stacked$Day == df$Day[r])
      
      df_daily_stacked[find.row, "Extent"] <- df$Extent[r]
    }
    
    #   It may occur that between 1979 - Aug 1987, February 29th is filled
    year.sub <- df$Year[which(df$Day == 29 & df$Month == 2 & df$Year %in% c(1979:1987))]
    for (yy in year.sub){
      row.sub <- which(df_daily_stacked$Day == 28 & df_daily_stacked$Month == 2 & df_daily_stacked$Year == yy)
      df_daily_stacked$Extent[row.sub] <- df$Extent[which(df$Day == 29 & df$Month == 2 & df$Year == yy)]
    }
    
    #   Fill the missing dates (1979 - Aug 1987) & Fill the First Observation manually
    df_daily_stacked$Extent[1] <- 14.791
    missing.days <- which(is.na(df_daily_stacked$Extent[1:which(df_daily_stacked$Year == 1987 &
                                                                   df_daily_stacked$Month == 8 &
                                                                   df_daily_stacked$Day == 20)]))
    for (r in missing.days){
      df_daily_stacked$Extent[r] <- mean(c(df_daily_stacked$Extent[r-1],
                                            df_daily_stacked$Extent[r+1]))
    }
  }
  
  ################################################################################################
  #
  #     00)  Real Observations: Create a dataframe in the "correct" panel-like format
  #
  ################################################################################################
  
  df_real.obs.daily <- data.frame(matrix(NA, nrow = length(unique(df$Year)), ncol = length(daily.colnames), 
                                          dimnames = list(c(unique(df$Year)), daily.colnames)), check.names = F)
  
  for (r in 1:nrow(df_real.obs.daily)){
    for (c in 1:ncol(df_real.obs.daily)){
      mon.c <- which(mon == substr(colnames(df_real.obs.daily)[c],1,3))
      day.c <- substr(colnames(df_real.obs.daily)[c],gregexpr(pattern ='_',colnames(df_real.obs.daily)[c])[[1]] + 1,
                      nchar(colnames(df_real.obs.daily)[c]))
      year.month.day_idx <- which(df_daily_stacked$Year == as.numeric(rownames(df_real.obs.daily)[r]) & 
                                    df_daily_stacked$Month == mon.c &
                                    df_daily_stacked$Day == as.numeric(day.c))
      if (length(year.month.day_idx) > 0){
        df_real.obs.daily[r,c] <- mean(df_daily_stacked$Extent[year.month.day_idx])
      }
    }
  }
  
  ################################################################################################
  #
  #      00)  Run a Monthly Dummy Regression
  #
  ################################################################################################
  df_daily_stacked <- cbind(df_daily_stacked,matrix(0,nrow=nrow(df_daily_stacked), ncol=length(mon)))
  colnames(df_daily_stacked)[5:ncol(df_daily_stacked)] <- mon
  
  for (mm in 1:length(mon)){
    df_daily_stacked[which(df_daily_stacked$Month == mm), mon[mm]] <- 1
  }
  formula.dummy <- paste0("Extent ~ ",paste0(mon, collapse = " + "), " - 1")
  
  reg.dummy <- lm(as.formula(formula.dummy), data = df_daily_stacked)
  summary(reg.dummy)
  
  ################################################################################################
  #
  #     I)  Synthetic Days: Create a Daily-Stacked dataframe, in which ALL days are "synthetic"-"m.star" days
  #
  ################################################################################################
  
  df_daily_synthetic <- df_daily_stacked[,1:4]
  m.star_coeff <- reg.dummy$coefficients[m.star]
  
  for (mm in 1:length(mon)){
    mm_coeff <- reg.dummy$coefficients[mon[mm]]
    syn.value <-  df_daily_synthetic$Extent[which(df_daily_synthetic$Month == mm)] - mm_coeff + m.star_coeff
    df_daily_synthetic[which(df_daily_synthetic$Month == mm),"SIE_syn"] <- syn.value
  }
  
  
  ################################################################################################
  #
  #     I)  Synthetic Days: Create a dataframe in the "correct" panel-like format
  #
  ################################################################################################
  
  df_daily_synthetic_panel <- data.frame(matrix(NA, nrow = length(unique(df$Year)), ncol = length(daily.colnames), 
                                                 dimnames = list(c(unique(df$Year)), daily.colnames)), check.names = F)
  
  for (r in 1:nrow(df_daily_synthetic_panel)){
    for (c in 1:ncol(df_daily_synthetic_panel)){
      mon.c <- which(mon == substr(colnames(df_daily_synthetic_panel)[c],1,3))
      day.c <- substr(colnames(df_daily_synthetic_panel)[c],gregexpr(pattern ='_',colnames(df_daily_synthetic_panel)[c])[[1]] + 1,
                      nchar(colnames(df_daily_synthetic_panel)[c]))
      year.month.day_idx <- which(df_daily_synthetic$Year == as.numeric(rownames(df_daily_synthetic_panel)[r]) & 
                                    df_daily_synthetic$Month == mon.c &
                                    df_daily_synthetic$Day == as.numeric(day.c))
      if (length(year.month.day_idx) > 0){
        df_daily_synthetic_panel[r,c] <- mean(df_daily_synthetic$SIE_syn[year.month.day_idx])
      }
    }
  }
  
  colnames(df_daily_synthetic_panel) <- paste0("s",daily.colnames)
  
  
  
  #########################################################################################################################
  #
  #       II) Synthetic Months: Create a monthly panel-like dataframe, in which ALL months are "synthetic"-"m.star" months
  #
  #########################################################################################################################
  
  # Compute monthly-averages from daily-data
  df_monthly_df <- data.frame(matrix(NA, nrow = length(unique(df$Year)), ncol = 12, 
                                      dimnames = list(c(unique(df$Year)), c(1:12))), check.names = F)
  for (r in 1:nrow(df_monthly_df)){
    for (c in 1:ncol(df_monthly_df)){
      # First Check if Number of Observations is > 10
      year.month_idx <- which(df$Year == as.numeric(rownames(df_monthly_df)[r]) & 
                                df$Month == as.numeric(colnames(df_monthly_df)[c]))
      if (length(year.month_idx) > 10){
        df_monthly_df[r,c] <- mean(df$Extent[year.month_idx])
      }
    }
  }
  
  # Set manually January 1988 to NA
  df_monthly_df["1988", "1"] <- NA
  
  colnames(df_monthly_df) <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
  
  #   Export the REAL OBSERVATIONS
  df_real.obs.panel <- cbind(df_monthly_df, df_real.obs.daily)
  
  
  #   Start the Synthetic-Month-Computations
  df_monthly_synthetic <- data.frame(matrix(NA, nrow = nrow(df_monthly_df), ncol = 12,
                                             dimnames = list(rownames(df_monthly_df),paste0("s",mon))))
  m.star_coeff <- reg.dummy$coefficients[m.star]
  
  for (mm in 1:length(mon)){
    mm_coeff <- reg.dummy$coefficients[mon[mm]]
    syn.value <-  df_monthly_df[,mon[mm]] - mm_coeff + m.star_coeff
    df_monthly_synthetic[,paste0("s",mon[mm])] <- syn.value
  }
  
  
  
  #   Finally: Combine Syntehtic Days & Syntehtic Months
  df_synthetic_panel <- cbind(df_monthly_synthetic, df_daily_synthetic_panel)
  
  
  out <- list(df_real.obs.panel, df_synthetic_panel)
  names(out) <- c("SII_real.obs.panel", "SII_processed_nomissing_synthetic")
  
  return(out)
}