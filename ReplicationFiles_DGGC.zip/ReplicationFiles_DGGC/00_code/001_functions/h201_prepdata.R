h201_prepdata <- function(directory, m.star, XX.Days.start, XX.Days.end){
  
  mon <- c("sJAN", "sFEB", "sMAR", "sAPR", "sMAY", "sJUN", "sJUL", "sAUG", "sSEP", "sOCT", "sNOV", "sDEC")
  mon.freeze <- mon  
  days <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  
  #   Import the monthly-daily synthetic data
  SII_data <- read.csv(file = file.path(directory, 
                                        paste0("10_data/SyntheticData/SII_SyntheticPanel_",substr(m.star,2,4),".csv")))
  
  #   Assign the time-trend
  time <- data.frame("year" = SII_data$Year,"month" = rep(1:12,times = length(unique(SII_data$Year))))
  SII_data$trend <- seq(1,nrow(SII_data), by = 1)
  
  #   Assign Monthly-Indicators ---> BEWARE:  the dummies will be anchored @ "m.star" (your Y-Variable)
  #                             --->          i.e. if "m.star==SEP", SII_data[1:12,month] = c(10,11,12,1,2,3,4,5,6,7,8,9)
  #                             --->          because the "real" observation for "m.star" sits at the LAST data-point 
  #                                           in each year
  if (m.star == "sDEC"){
    mon.ind <- seq(1,12, by = 1)
  } else if (m.star == "sJAN"){
    mon.ind <- c(seq(2,12, by = 1),1)
  } else  {
    mon.ind <- c(seq(which(mon == m.star) + 1,length(mon), by = 1), 
                 seq(1,which(mon == m.star) - 1, by = 1), 
                 which(mon == m.star))
  }
  SII_data$month <- rep(mon.ind, times = length(unique(SII_data$Year)))
  
  #   Assign Summer-Winter dummies ---> summer == JUN-SEP; winter == NOV-MAR
  SII_data$summer <- 0
  SII_data$summer[which(SII_data$month %in% c(6,7,8,9))] <- 1
  SII_data$winter <- 0
  SII_data$winter[which(SII_data$month %in% c(1,2,3,11,12))] <- 1
  
  #   Assign monthly-dummies: "D[NUMBER]"
  for (mm in mon){
    mm.colname <- paste0("D",which(mon == mm))
    SII_data[,mm.colname] <- 0
    SII_data[which(SII_data$month == which(mon == mm)),mm.colname] <- 1
  }
  
  
  #   Freeze a copy of the dataset
  SII_data.true <- SII_data
  
  
  
  # If m.star == JAN | FEB | MAR | APR --> reshuffle!
  if (m.star == "sJAN" | m.star == "sFEB" | m.star == "sMAR" | m.star == "sAPR"){
    mon.idx <- 1:which(mon == m.star)
    mon.names <- mon[mon.idx]
    
    mon <- mon[-mon.idx]
    mon <- c(mon, mon.names)
    
    days.number <- days[mon.idx]
    days <- days[-mon.idx]
    days <- c(days, days.number)
    
  }
  
  #   Create a month-day index to ease the identification of "Last.XX.Days"
  month.day.index <- data.frame("month" = rep(mon, days))
  for (mm in mon){
    month.day.index[which(month.day.index$month == mm), "day"] <- rep(1:days[which(mon == mm)])
  }
  
  #   Set-up a data-frame: Column = RMSE; Rows = Sum(days in month (m.star-3), days in month (m.star-2), days in month (m.star-1), days in month (m.star))
  glide.chart <- data.frame(matrix(NA, nrow = sum(days[(which(mon == m.star) - 3):which(mon == m.star)]),
                                   ncol = 4, dimnames = list(c(c(paste0("(M*-3).", c(1:days[(which(mon == m.star) - 3)])),
                                                                 paste0("(M*-2).", c(1:days[(which(mon == m.star) - 2)])),
                                                                 paste0("(M*-1).", c(1:days[(which(mon == m.star) - 1)])),
                                                                 paste0("(M*).", c(1:days[(which(mon == m.star))])))),
                                                             c("Point", "SE2_up", "SE2_low","formula"))))
  
  
  #   Set-up a helping data-frame: Columns: Last.Month, This.Month, Day.This.Month
  help_df <- data.frame("Last.Month" = c(rep(mon[which(mon == m.star) - 4], times = days[(which(mon == m.star) - 3)]),
                                         rep(mon[which(mon == m.star) - 3], times = days[(which(mon == m.star) - 2)]),
                                         rep(mon[which(mon == m.star) - 2], times = days[(which(mon == m.star) - 1)]),
                                         rep(mon[which(mon == m.star) - 1], times = days[(which(mon == m.star) - 0)])),
                        "This.Month" = c(rep(mon[which(mon == m.star) - 3], times = days[(which(mon == m.star) - 3)]),
                                         rep(mon[which(mon == m.star) - 2], times = days[(which(mon == m.star) - 2)]),
                                         rep(mon[which(mon == m.star) - 1], times = days[(which(mon == m.star) - 1)]),
                                         rep(mon[which(mon == m.star) - 0], times = days[(which(mon == m.star) - 0)])),
                        "Day.This.Month" = c(1:days[(which(mon == m.star) - 3)],
                                             1:days[(which(mon == m.star) - 2)],
                                             1:days[(which(mon == m.star) - 1)],
                                             1:days[(which(mon == m.star) - 0)]))
  
  help_df$Last.Month <- c(as.character(help_df$Last.Month[2:nrow(help_df)]), m.star)
  
  #   Identify the "Days_XX.XX" ---> make a list of length "min(length(XX.Days.start),length(XX.Days.end))"
  list_XX.XX <- rep(list(NA),min(length(XX.Days.start),length(XX.Days.end)))
  if (length(list_XX.XX) > 0){
    for (ll in 1:length(list_XX.XX)){
      help_df.ll <- help_df
      for (dd in 1:nrow(help_df.ll)){
        today.row <- which(month.day.index$month == as.character(help_df.ll$This.Month[dd]) & 
                             month.day.index$day == help_df.ll$Day.This.Month[dd]) 
        
        # Determine the beginning of the XX-day-period
        help_df.ll[dd, "XX.Days.START"] <- NA
        help_df.ll$XX.Days.START[dd] <- paste0(month.day.index$month[today.row - (XX.Days.start[ll] - 1)], 
                                               month.day.index$day[today.row - (XX.Days.start[ll] - 1)],
                                               "_", month.day.index$day[today.row - (XX.Days.start[ll] - 1)])
        # Determine middle-part of the XX-day-period
        XX.interval <- XX.Days.start[ll] - XX.Days.end[ll]
        for (m in (XX.Days.start[ll] - 2):(XX.Days.end[ll] + 1)){
          help_df.ll[dd, paste0("XX.Days.START", (XX.interval-m))] <- NA
          help_df.ll[dd, paste0("XX.Days.START", (XX.interval-m))] <- paste0(month.day.index$month[today.row - m], 
                                                                             month.day.index$day[today.row - m],
                                                                             "_", month.day.index$day[today.row - m])
        }
        
        # Determine the end of the XX-day-period
        help_df.ll[dd, "XX.Days.END"] <- NA
        help_df.ll$XX.Days.END[dd] <- paste0(month.day.index$month[today.row - XX.Days.end[ll]], 
                                             month.day.index$day[today.row - XX.Days.end[ll]],"_", 
                                             month.day.index$day[today.row - XX.Days.end[ll]])
      }
      list_XX.XX[[ll]] <- help_df.ll
    } #This ends: for (ll in 1:length(list_XX.XX)){
  } # This ends: if (length(list_XX.XX) > 0){
  
  #   Use the previously frozen data-frame to re-set your working-dataframe
  SII_data <- SII_data.true
  
  
  # Store the daily densities in a list
  sample.range <- 10^7
  densities.daily <- data.frame(matrix(NA, nrow = nrow(glide.chart), ncol = 2, dimnames = list(c(),c("mean","se"))))
  
  output <- list(SII_data, SII_data.true, glide.chart, help_df, list_XX.XX, densities.daily, 
                 month.day.index, mon.freeze)
  names(output) <- c("SII_data", "SII_data.true", "glide.chart", "help_df", "list_XX.XX", "densities.daily",
                     "month.day.index", "mon")
  
  return(output)
  
}