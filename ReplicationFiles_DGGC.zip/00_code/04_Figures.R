###################################################################################################################
#
#                           This File Plots the Figures
#
#
#           00)    Extract "ERR" matrices from the Year-Month Files
#           00)    Extract glide-charts (with point-estimates) from the Year-Month Files
#
#           I)     Figure 2
#           II)    Figure 3
#           III)   Figure 4 -- Quadrant 1
#           IV)    Figure 4 -- Quadrants 2-4
#           V)     Figure 1
#
###################################################################################################################
rm(list = ls())
library(ggplot2)
library(abind)

# ============================================== USER INTERACTION: Start ============================================== #

directory <- "/Users/maximilian/Dropbox/ReplicationFiles"

# ============================================== USER INTERACTION: End ============================================== #

###################################################################################################################
#
#                   00)    Extract "ERR" matrices from the Year-Month Files
#
###################################################################################################################

for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")){
  for (yy in c(2012:2021)){
    
    # --- Load the Estimation Output
    load(file = file.path(directory,paste0("10_data/101_output/s",mm,"_",yy,".RData")))
    
    # --- Overwrite the directory
    directory <- directory_fix
    
    # --- Save the Glide-charts
    save(ERR, file = file.path(directory,paste0("10_data/101_output/mat_ERR/ERR_s",mm,"_",yy,".RData")))
    rm(ERR)
  }
}


###################################################################################################################
#
#                   00)    Extract glide-charts (with point-estimates) from the Year-Month Files
#
###################################################################################################################

for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")){
  for (yy in c(2012:2021)){
    
    # --- Load the Estimation Output
    load(file = file.path(directory,paste0("10_data/101_output/s",mm,"_",yy,".RData")))
    
    # --- Overwrite the directory
    directory <- directory_fix
    
    # --- Get the Glide-Chart
    glide_chart <- get(paste0("glide.chart.",yy))
    
    # --- Save the Glide-charts
    save(glide_chart, 
         file = file.path(directory,paste0("10_data/101_output/mat_glidechart/GlideChart_s",mm,"_",yy,".RData")))
  }
}


###################################################################################################################
#
#                   I)    Figure 2
#
###################################################################################################################

# ---- Which year is it you are looking at?
my_year <- 2021

for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")){
  
  # --- Data is split into two batches
  load(file = file.path(directory,paste0("10_data/101_output/s", mm,"_",my_year,"_oob_1.RData")))
  help_df_1 <- get(paste0("glide.chart.",my_year))
  # --- --- Reset directory
  directory <- directory_fix
  load(file = file.path(directory,paste0("10_data/101_output/s", mm,"_",my_year,"_oob_2.RData")))
  help_df_2 <- get(paste0("glide.chart.",my_year))
  # --- --- Reset directory
  directory <- directory_fix
  
  # --- Merge both "help_df_[1/2]
  plot.df <- data.frame(rbind(help_df_1[1:60,],help_df_2[61:nrow(help_df_2),]))
  
  
  # --- Some Graphing-Layout specifications
  step.size.Y <- 0.2
  max.Yaxis <- 0.8
  ratio.display <- 16/9
  ratio.values <- (max(nrow(glide.chart))-min(0))/(max.Yaxis-0)
  
  breaks <- seq(-120,0, by = 5)
  labels <- as.character(breaks)
  labels[!(breaks %in% seq(-120,0, by = 30))] <- ''
  tick.sizes <- rep(0.75, length(breaks))
  tick.sizes[!(breaks %in% seq(-120,0, by = 30))] <- 0.5
  tick.sizes.unit <- unit(x = tick.sizes,units = "cm")
  
  # --- Some Polishing-Up
  colnames(plot.df) <- gsub("\\-","\\.",colnames(plot.df))
  plot.df[,"time"] <- (-nrow(glide.chart)+1):0
  
  # --- Some Re-Naming might be necessary:
  if(any(colnames(plot.df) == "MRF.mse.in")){colnames(plot.df)[which(colnames(plot.df) == "MRF.mse.in")] <- "FEML.mse.in"}
  if(any(colnames(plot.df) == "MRF.trend.today.mse.in")){
    colnames(plot.df)[which(colnames(plot.df) == "MRF.trend.today.mse.in")] <- "FEML.Pocket.mse.in"}
  if(any(colnames(plot.df) == "OLS.mse.in")){colnames(plot.df)[which(colnames(plot.df) == "OLS.mse.in")] <- "FELR.mse.in"}
  if(any(colnames(plot.df) == "OLS.trend.today.mse.in")){
    colnames(plot.df)[which(colnames(plot.df) == "OLS.trend.today.mse.in")] <- "FELR.Pocket.mse.in"}
  
  
  # --- Store the names of each Month --> there is also a built-in-function in R, but that took me a while to figure out...
  month.names <- c("January", "February", "March", "April", "May", "June", "July", 
                   "August", "September", "October", "November", "December")
  
  # --- Plot the Data
  xlimit <- min(plot.df$time[1],-120)
  g1 <- ggplot(data = plot.df)
  g1 <- g1 +  geom_line(aes(x = time, y = (FEML.mse.in)^0.5, color="FEML"), size = 2) +
    geom_line(aes(x = time, y = (FEML.Pocket.mse.in)^0.5, color="Pocket FEML"), size = 2) +
    geom_line(aes(x = time, y = (FELR.mse.in)^0.5, color="FELR"), size = 2) +
    geom_line(aes(x = time, y = (FELR.Pocket.mse.in)^0.5, color="Pocket FELR"), size = 2)
  
  g1 <- g1 + scale_x_continuous(name = "", breaks = breaks, limits = c(xlimit, plot.df$time[nrow(plot.df)]), 
                                expand = c(0,0), labels = labels) +
    scale_y_continuous(name = "", breaks = seq(step.size.Y, max.Yaxis + step.size.Y, by = step.size.Y), 
                       labels = c(sprintf("%.2f",seq(step.size.Y,max.Yaxis + step.size.Y, by=step.size.Y))), 
                       limits = c(0,max.Yaxis), expand = c(0,0)) +
    labs(title = month.names[which(prep.data$mon == m.star)]) +
    coord_fixed(ratio=ratio.values/ratio.display) +
    theme_bw() +
    theme(legend.position="", legend.title=element_blank(), legend.text = element_text(size = 20),
          legend.direction = "horizontal", text = element_text(size = 34),
          plot.margin = ggplot2::margin(0.35, 0.67, 0, 0.3, "cm"),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.ticks.x = element_line(size = tick.sizes),
          axis.text.x = element_text(size = 40),
          axis.text.y = element_text(size = 40),
          axis.title.y = element_text(margin = ggplot2::margin(t = 0, r = 0, b = 0, l = 0)),
          axis.ticks.length = unit(10, "mm"),
          plot.title = element_text(hjust = 0.5, size = 40)) +
    scale_color_manual(values = c("FEML" = 'dodgerblue',
                                  "Pocket FEML" = 'firebrick3',
                                  "FELR" = 'darkorchid',
                                  "Pocket FELR" = 'gold3')) +
    guides(col=guide_legend(nrow=2,byrow=TRUE))
  
  g1
  if (T){
    ggsave(file = paste0(directory,"/20_figures/RMSEs_",m.star,"_",my_year,"_FELR_MRF.png"), 
           plot = g1, device = "png",
           width = 30, height = 20, units = "cm", dpi = 150)
  }
  
}

###################################################################################################################
#
#                 II)     Figure 3
#
###################################################################################################################
library(ggplot2)
library(abind)

#   Load A SINGLE output file for FEML & FELR
load(file = file.path(directory_fix,paste0("10_data/101_output/sSEP_2021.RData")))

# Re-set the directory:
directory <- directory_fix

# ======================================== USER INTERACTION: Start ============================================= #

#   Over which years do you want to determine the Mean-Absolute Prediction Error?
start.year <- 2012
end.year <- 2021

#   Do you want RMSE or MAE to be plotted? ["rmse";"mae"]
I_want_err <- "rmse"

# ======================================== USER INTERACTION: End ============================================= #


# --- Loop over months
for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")){


  #   Load the ERR-matrices for FEML & FELR
  for (yy in c(start.year:end.year)){
    load(file = file.path(directory,paste0("10_data/101_output/mat_ERR/ERR_s",mm,"_", yy,".RData")))
    assign(paste0("ERR_",yy),ERR)
    rm(ERR)
  }
  
  # --- Prepare the Errors for plotting  
  r.range <- 1:dim(get(paste0("ERR_",start.year)))[3]
  ERR.store.usual <- array(NA, dim = c(length(colnames(Rsq_out)),end.year-start.year+1,length(r.range)))

  for (yy in c(start.year:end.year)){
    
    pos.yy <- which(c(start.year:end.year) == yy)
    ERR.store.usual[,pos.yy,1:length(r.range)] <- get(paste0("ERR_",yy))[1:length(colnames(Rsq_out)),1,r.range]
    
    # Next "yy"
  }
  
  ERR.store <- ERR.store.usual
  
  if (I_want_err == "mae"){
    
    # --- Absolute Error
    abs.ERR.store <- abs(ERR.store)
    
    # --- Calculate the Mean across years
    curr.df <- apply(abs.ERR.store,c(1,3), mean) # For Checking: mean(abs.ERR.store[9,,])
    
    # --- Collect the Errors in a data frame
    curr.df <- setNames(data.frame(t(curr.df)),c(colnames(Rsq_out)))
    
  } else if (I_want_err == "rmse"){
    
    # --- Squared Error
    abs.ERR.store <- ERR.store^2
    
    # --- Calculate the Mean across years
    curr.df <- apply(abs.ERR.store,c(1,3), mean)  # For Checking: mean(abs.ERR.store[9,,])
    
    # --- Collect the Errors in a data frame ---> For RMSEs, take the square-root
    curr.df <- setNames(data.frame(sqrt(t(curr.df))),c(colnames(Rsq_out)))
  }
  
  # --- Define Colors
  col.vec <- col_vector[c(1:3,5:(length(colnames(curr.df))+1))]
  
  # --- Some Re-Naming might be necessary:
  colnames(curr.df) <- gsub("\\-","\\.",colnames(curr.df))
  colnames(curr.df) <- gsub("\\_","\\.",colnames(curr.df))
  if(any(colnames(curr.df) == "MRF")){colnames(curr.df)[which(colnames(curr.df) == "MRF")] <- "FEML"}
  if(any(colnames(curr.df) == "MRF.trend.today")){
    colnames(curr.df)[which(colnames(curr.df) == "MRF.trend.today")] <- "FEML.Pocket"}
  if(any(colnames(curr.df) == "OLS")){colnames(curr.df)[which(colnames(curr.df) == "OLS")] <- "FELR"}
  if(any(colnames(curr.df) == "OLS.trend.today")){
    colnames(curr.df)[which(colnames(curr.df) == "OLS.trend.today")] <- "FELR.Pocket"}

  
  # --- Some Graphing-Layout specifications
  breaks <- seq(-120,0, by = 5)
  labels <- as.character(breaks)
  labels[!(breaks %in% seq(-120,0, by = 30))] <- ''
  tick.sizes <- rep(0.75, length(breaks))
  tick.sizes[!(breaks %in% seq(-120,0, by = 30))] <- 0.5
  tick.sizes.unit <- unit(x = tick.sizes,units = "cm")
  
  ylim.min <- 0  
  ylim.max <- 0.8 
  step.size <- ylim.max / 4 
  ratio.display <- 16/9
  ratio.values <- (max(nrow(glide.chart))-min(0))/(ylim.max-(0))
  xlimit <- min(curr.df$time[1],-120)
  
  # --- Add a "days-left-till-target-month-end" column
  curr.df[,"time"] <- (-nrow(curr.df)+1):0
  
  # --- Define the title of the plot
  if (start.year == end.year){
    yy.title.name <- start.year
  } else {
    yy.title.name <- paste0(start.year,"-",end.year)
  }
  month.names <- c("January", "February", "March", "April", "May", "June", 
                   "July", "August", "September", "October", "November", "December")
  
  
  # --- Plot the Data
  xlimit <- min(curr.df$time[1],-120)
  g1 <- ggplot(data = curr.df)
  g1 <- g1 +  geom_line(aes(x = time, y = FEML, color="FEML"), size = 2) +
    geom_line(aes(x = time, y = FEML.Pocket, color="Pocket FEML"), size = 2) +
    geom_line(aes(x = time, y = FELR, color="FELR"), size = 2) +
    geom_line(aes(x = time, y = FELR.Pocket, color="Pocket FELR"), size = 2)
  
  g1 <- g1 + scale_x_continuous(name = "", breaks = breaks, limits = c(xlimit, curr.df$time[nrow(curr.df)]), 
                                expand = c(0,0), labels = labels) +
    scale_y_continuous(name = "", breaks = seq(ylim.min+step.size, ylim.max, by = step.size), 
                       labels = c(sprintf("%.2f",seq(ylim.min+step.size, ylim.max, by = step.size))), 
                       limits = c(0,ylim.max), expand = c(0,0)) +
    labs(title = month.names[which(prep.data$mon == paste0("s",mm))]) +
    coord_fixed(ratio=ratio.values/ratio.display) +
    theme_bw() +
    theme(legend.position="", legend.title=element_blank(), legend.text = element_text(size = 20),
          legend.direction = "horizontal", text = element_text(size = 34),
          plot.margin = ggplot2::margin(t=0.35, r=0.67, b=0, l=0.3, "cm"),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.ticks.x = element_line(size = tick.sizes),
          axis.text.x = element_text(size = 40),
          axis.text.y = element_text(size = 40),
          axis.title.y = element_text(margin = ggplot2::margin(t = 0, r = 0, b = 0, l = 0)),
          axis.ticks.length = unit(10, "mm"),
          plot.title = element_text(hjust = 0.5, size = 40)) +
    scale_color_manual(values = c("FEML" = 'dodgerblue',
                                  "Pocket FEML" = 'firebrick3',
                                  "FELR" = 'darkorchid',
                                  "Pocket FELR" = 'gold3')) +
    guides(col=guide_legend(nrow=1,byrow=TRUE))
    
  
  if (T){
    ggsave(file = paste0(directory,"/20_figures/RMSFEoos_",mm,"_",
                         substr(start.year,3,4),substr(end.year,3,4),"_v220423.png"), 
           plot = g1, device = "png",
           width = 30, height = 20, units = "cm", dpi = 150)
  }
  
}


###################################################################################################################
#
#                III)     Figure 4 -- Quadrant 1
#                         
#
###################################################################################################################


# =================================== USER INTERACTION: Start ========================================== #

# --- Which models do you want to look at?
my_models <- c("MRF","MRF.trend.today","OLS-trend-today","OLS")
FEML_models <- c("MRF","MRF.trend.today")

#   Do you want RMSE or MAE to be plotted? ["rmse";"mae"]
I_want_err <- "rmse"

#   Over which years do you want to determine the Mean-Absolute Prediction Error?
start.year <- 2012
end.year <- 2021

# =================================== USER INTERACTION: End ========================================== #


#   Load A SINGLE output file for MRF & FELR
load(file = file.path(directory,paste0("10_data/101_output/sJAN_2012.RData")))

# --- Check if old names are used or already new names:
if(!any(colnames(Rsq_out) == "MRF")){
  if(any(my_models == "MRF")){
    my_models[which(my_models == "MRF")] <- "FEML"
  }
  if (any(FEML_models == "MRF")) {
    FEML_models[which(FEML_models == "MRF")] <- "FEML"
  }
}
if(!any(colnames(Rsq_out) == "MRF.trend.today")){
  if(any(my_models == "MRF.trend.today")){
    my_models[which(my_models == "MRF.trend.today")] <- "FEML.Pocket"
  }
  if (any(FEML_models == "MRF.trend.today")) {
    FEML_models[which(FEML_models == "MRF.trend.today")] <- "FEML.Pocket"
  }
}
if(!any(colnames(Rsq_out) == "OLS")){
  if(any(my_models == "OLS")){
    my_models[which(my_models == "OLS")] <- "FELR"
  }
  if (any(FEML_models == "OLS")) {
    FEML_models[which(FEML_models == "OLS")] <- "FELR"
  }
}
if(!any(colnames(Rsq_out) == "OLS-trend-today")){
  if(any(my_models == "OLS-trend-today")){
    my_models[which(my_models == "OLS-trend-today")] <- "FELR.Pocket"
  }
  if (any(FEML_models == "OLS-trend-today")) {
    FEML_models[which(FEML_models == "OLS-trend-today")] <- "FELR.Pocket"
  }
}
  
# Re-set the directory:
directory <- directory_fix

minfrac_df <- data.frame(cbind(model=FEML_models,matrix(NA, nrow=length(FEML_models),ncol=12,
                                                        dimnames = list(c(),c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")))),
                         stringsAsFactors = F)

for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")){
  
  
  #   Load the ERR-matrices for FEML & FELR
  for (yy in c(start.year:end.year)){
    load(file = file.path(directory,paste0("10_data/101_output/mat_ERR/ERR_s",mm,"_", yy,".RData")))
    assign(paste0("ERR_",yy),ERR)
    rm(ERR)
  }

  
  
  r.range <- 1:dim(get(paste0("ERR_",start.year)))[3]
  ERR.store.usual <- array(NA, dim = c(length(colnames(Rsq_out)),end.year-start.year+1,length(r.range)))

  for (yy in c(start.year:end.year)){
    
    pos.yy <- which(c(start.year:end.year) == yy)
    ERR.store.usual[,pos.yy,1:length(r.range)] <- get(paste0("ERR_",yy))[1:length(colnames(Rsq_out)),1,r.range]

    
    # Next "yy"
  }
  ERR.store <- ERR.store.usual
  
  if (I_want_err == "mae"){
    
    # --- Absolute Error
    abs.ERR.store <- abs(ERR.store)
    
    # --- Calculate the Mean across years
    curr.df <- apply(abs.ERR.store,c(1,3), mean) # For Checking: mean(abs.ERR.store[9,,])
    
    # --- Collect the Errors in a data frame
    curr.df <- setNames(data.frame(t(curr.df)),c(colnames(Rsq_out)))
    
  } else if (I_want_err == "rmse"){
    
    # --- Squared Error
    abs.ERR.store <- ERR.store^2
    
    # --- Calculate the Mean across years
    curr.df <- apply(abs.ERR.store,c(1,3), mean)  # For Checking: mean(abs.ERR.store[9,,])
    
    # --- Collect the Errors in a data frame ---> For RMSEs, take the square-root
    curr.df <- setNames(data.frame(sqrt(t(curr.df))),c(colnames(Rsq_out)))
  }
  
  # --- Define Colors
  col.vec <- col_vector[c(1:3,5:(length(colnames(curr.df))+1))]
  
  # ---- Only keep those models that are in "my_models"
  curr.df <- curr.df[,which(colnames(curr.df) %in% my_models)]
  
  #   Calculate which Model gives the lowest Error Each Day
  min_df <- data.frame("model" = colnames(curr.df), "total" = rep(0,ncol(curr.df)))
  t_curr.df <- t(curr.df)
  for (rr in c(1:(nrow(curr.df)))){
    
    min_model <- rownames(t_curr.df)[which(t_curr.df[,rr] == min(t_curr.df[,rr], na.rm=T))] 
    
    # If there are several models, accredit all
    for (ii in min_model){
      min_df$total[which(min_df$model == ii)] <- min_df$total[which(min_df$model == ii)] + 1
    }
  }
  
  min_df$relative <- min_df$total / sum(min_df$total)
  
  
  # --- Assign the fraction to the corresponding month
  for (mod in minfrac_df$model){
    minfrac_df[which(minfrac_df$model == mod), mm] <- min_df$relative[which(min_df$model == mod)]
  }
  
}  


# ---- Plot the Data
plot_df <- data.frame("month"=rep(colnames(minfrac_df)[-1],times=2),
                      "val"= as.numeric(c(t(as.matrix(minfrac_df[1:nrow(minfrac_df),2:ncol(minfrac_df)])))),
                      "name"= rep(minfrac_df$model, each=ncol(minfrac_df)-1),stringsAsFactors = F)
plot_df$month <- factor(plot_df$month, levels = c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC"))
plot_df <- na.omit(plot_df)

if ("MRF" %in% FEML_models){
  plot_df$name[plot_df$name == "MRF"] <- 'FEML'
  plot_df$name[plot_df$name == "MRF.trend.today"] <- 'Pocket FEML'
} else {
  plot_df$name[plot_df$name == "FEML.Pocket"] <- 'Pocket FEML'
  
}



# --- Some Graphing-Layout specifications
ylim.min <- 0
ylim.max <- 1.0 
step.size <- 0.2

# --- Define the title of the plot
if (start.year == end.year){
  yy.title.name <- start.year
} else {
  yy.title.name <- paste0(start.year,"-",end.year)
}

month.names <- c("January", "February", "March", "April", "May", "June", 
                 "July", "August", "September", "October", "November", "December")
month.abbrev <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", 
                  "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")

DayCount.graph <-  ggplot(data = plot_df, aes(x=month, y=val, fill=name)) + theme_bw() + 
  labs(title = "All Days") +
  geom_bar(stat = "identity", position = "stack") + 
  scale_fill_manual(values=c("FEML" = 'dodgerblue', "Pocket FEML"='firebrick3')) +
  scale_y_continuous(name = "", breaks = seq(ylim.min, ylim.max, by = step.size), 
                     labels = sprintf("%.2f",round(seq(ylim.min,ylim.max, by=step.size), digits=2)), 
                     limits = c(ylim.min,ylim.max), expand = c(0,0)) +
  scale_x_discrete(name = "") +
  theme(legend.position = "", legend.title=element_blank(), legend.text = element_text(size = 25),
        legend.direction = "horizontal",
        plot.title = element_text(hjust = 0.5, size = 40,face = "bold"),
        axis.text.x = element_text(size = 25), # If used as single figure: 20
        axis.text.y = element_text(size = 30)) # If used as single figure: 20

DayCount.graph


if (T){
  ggsave(file = paste0(directory,"/20_figures/DayCountsRelativeFreq_Stacked_byMonth_FEMLs.png"), 
         plot = DayCount.graph, device = "png",
         width = 30, height = 20, units = "cm", dpi = 150)
}
  




###################################################################################################################
#
#                IV)     Figure 4 -- Quadrants 2-4
#                         
#
###################################################################################################################



# =================================== USER INTERACTION: Start ========================================== #

# --- Which models do you want to look at?
my_models <- c("MRF","MRF.trend.today","OLS-trend-today","OLS")
FEML_models <- c("MRF","MRF.trend.today")

# --- Define the Intervals over which you want to compare the models:
my_ranges <- list(c(-120:-90),c(-89:-60),c(-59:-30),c(-29:0))

#   Do you want RMSE or MAE to be plotted? ["rmse";"mae"]
I_want_err <- "rmse"

#   Over which years do you want to determine the Mean-Absolute Prediction Error?
start.year <- 2012
end.year <- 2021

# =================================== USER INTERACTION: End ========================================== #


#   Load A SINGLE output file for MRF & FELR
load(file = file.path(directory,paste0("10_data/101_output/sJAN_2012.RData")))

# --- Check if old names are used or already new names:
if(!any(colnames(Rsq_out) == "MRF")){
  if(any(my_models == "MRF")){
    my_models[which(my_models == "MRF")] <- "FEML"
  }
  if (any(FEML_models == "MRF")) {
    FEML_models[which(FEML_models == "MRF")] <- "FEML"
  }
}
if(!any(colnames(Rsq_out) == "MRF.trend.today")){
  if(any(my_models == "MRF.trend.today")){
    my_models[which(my_models == "MRF.trend.today")] <- "FEML.Pocket"
  }
  if (any(FEML_models == "MRF.trend.today")) {
    FEML_models[which(FEML_models == "MRF.trend.today")] <- "FEML.Pocket"
  }
}
if(!any(colnames(Rsq_out) == "OLS")){
  if(any(my_models == "OLS")){
    my_models[which(my_models == "OLS")] <- "FELR"
  }
  if (any(FEML_models == "OLS")) {
    FEML_models[which(FEML_models == "OLS")] <- "FELR"
  }
}
if(!any(colnames(Rsq_out) == "OLS-trend-today")){
  if(any(my_models == "OLS-trend-today")){
    my_models[which(my_models == "OLS-trend-today")] <- "FELR.Pocket"
  }
  if (any(FEML_models == "OLS-trend-today")) {
    FEML_models[which(FEML_models == "OLS-trend-today")] <- "FELR.Pocket"
  }
}

# Re-set the directory:
directory <- directory_fix


for (ra in 1:length(my_ranges)){

  minfrac_df <- data.frame(cbind(model=FEML_models,matrix(NA, nrow=length(FEML_models),ncol=12,
                                                          dimnames = list(c(),c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")))),
                           stringsAsFactors = F)
  
  for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC")){

    
    #   Load the ERR-matrices for FEML & FELR
    for (yy in c(start.year:end.year)){
      load(file = file.path(directory,paste0("10_data/101_output/mat_ERR/ERR_s",mm,"_", yy,".RData")))
      assign(paste0("ERR_",yy),ERR)
      rm(ERR)
    }
    
    
    
    r.range <- 1:dim(get(paste0("ERR_",start.year)))[3]
    ERR.store.usual <- array(NA, dim = c(length(colnames(Rsq_out)),end.year-start.year+1,length(r.range)))
    
    for (yy in c(start.year:end.year)){
      
      pos.yy <- which(c(start.year:end.year) == yy)
      ERR.store.usual[,pos.yy,1:length(r.range)] <- get(paste0("ERR_",yy))[1:length(colnames(Rsq_out)),1,r.range]
      
      
      # Next "yy"
    }
    ERR.store <- ERR.store.usual
    
    if (I_want_err == "mae"){
      
      # --- Absolute Error
      abs.ERR.store <- abs(ERR.store)
      
      # --- Calculate the Mean across years
      curr.df <- apply(abs.ERR.store,c(1,3), mean) # For Checking: mean(abs.ERR.store[9,,])
      
      # --- Collect the Errors in a data frame
      curr.df <- setNames(data.frame(t(curr.df)),c(colnames(Rsq_out)))
      
    } else if (I_want_err == "rmse"){
      
      # --- Squared Error
      abs.ERR.store <- ERR.store^2
      
      # --- Calculate the Mean across years
      curr.df <- apply(abs.ERR.store,c(1,3), mean)  # For Checking: mean(abs.ERR.store[9,,])
      
      # --- Collect the Errors in a data frame ---> For RMSEs, take the square-root
      curr.df <- setNames(data.frame(sqrt(t(curr.df))),c(colnames(Rsq_out)))
    }
    
    # --- Define Colors
    col.vec <- col_vector[c(1:3,5:(length(colnames(curr.df))+1))]
    
    # ---- Only keep those models that are in "my_models"
    curr.df <- curr.df[,which(colnames(curr.df) %in% my_models)]
    
    # ---- Assign 'days until target-month end'
    curr.df$days_out <- c((-nrow(curr.df)+1):0)
    
    #   Calculate which Model gives the lowest Error Each Day in the Interval [ra]
    min_df <- data.frame("model" = colnames(curr.df)[-ncol(curr.df)], "total" = rep(0,ncol(curr.df)-1))
    t_curr.df <- t(curr.df[,-ncol(curr.df)])
    for (rr in my_ranges[[ra]]){
      
      day_rr <- which(curr.df$days_out == rr)
      if (length(day_rr) > 0){
        min_model <- rownames(t_curr.df)[which(t_curr.df[,day_rr] == min(t_curr.df[,day_rr], na.rm=T))] 
      }
      
      # If there are several models, accredit all
      for (ii in min_model){
        min_df$total[which(min_df$model == ii)] <- min_df$total[which(min_df$model == ii)] + 1
      }
    }
    
    min_df$relative <- min_df$total / sum(min_df$total)
    
    
    # --- Assign the fraction to the corresponding month
    for (mod in minfrac_df$model){
      minfrac_df[which(minfrac_df$model == mod), mm] <- min_df$relative[which(min_df$model == mod)]
    }
    
  }  
  
  
  # ---- Plot the Data
  plot_df <- data.frame("month"=rep(colnames(minfrac_df)[-1],times=2),
                        "val"= as.numeric(c(t(as.matrix(minfrac_df[1:nrow(minfrac_df),2:ncol(minfrac_df)])))),
                        "name"= rep(minfrac_df$model, each=ncol(minfrac_df)-1),stringsAsFactors = F)
  plot_df$month <- factor(plot_df$month, levels = c("JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL","AUG","SEP", "OCT", "NOV","DEC"))
  plot_df <- na.omit(plot_df)
  
  if ("MRF" %in% FEML_models){
    plot_df$name[plot_df$name == "MRF"] <- 'FEML'
    plot_df$name[plot_df$name == "MRF.trend.today"] <- 'Pocket FEML'
  } else {
    plot_df$name[plot_df$name == "FEML.Pocket"] <- 'Pocket FEML'
    
  }
  
  
  
  # --- Some Graphing-Layout specifications
  ylim.min <- 0
  ylim.max <- 1.0 
  step.size <- 0.2
  
  # --- Define the title of the plot
  if (start.year == end.year){
    yy.title.name <- start.year
  } else {
    yy.title.name <- paste0(start.year,"-",end.year)
  }
  
  month.names <- c("January", "February", "March", "April", "May", "June", 
                   "July", "August", "September", "October", "November", "December")
  month.abbrev <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", 
                    "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
  
  DayCount.graph <-  ggplot(data = plot_df, aes(x=month, y=val, fill=name)) + theme_bw() + 
    labs(title = paste0("Days: [", my_ranges[[ra]][1],"; " , my_ranges[[ra]][length(my_ranges[[ra]])],"]")) +
    geom_bar(stat = "identity", position = "stack") + 
    scale_fill_manual(values=c("FEML" = 'dodgerblue', "Pocket FEML"='firebrick3')) +
    scale_y_continuous(name = "", breaks = seq(ylim.min, ylim.max, by = step.size), 
                       labels = sprintf("%.2f",round(seq(ylim.min,ylim.max, by=step.size), digits=2)), 
                       limits = c(ylim.min,ylim.max), expand = c(0,0)) +
    scale_x_discrete(name = "") +
    theme(legend.position = "", legend.title=element_blank(), legend.text = element_text(size = 25),
          legend.direction = "horizontal",
          plot.title = element_text(hjust = 0.5, size = 40),
          axis.text.x = element_text(size = 25),
          axis.text.y = element_text(size = 30)) 
  
  #DayCount.graph
  
  #dev.off()
  if (T){
    ggsave(file = paste0(directory,"/20_figures/DayCountsRelativeFreq_Stacked_byMonth_FEMLs_B",ra,".png"), 
           plot = DayCount.graph, device = "png",
           width = 30, height = 20, units = "cm", dpi = 150)
  }
  
}



###################################################################################################################
#
#                 V)     Figure 1
#
###################################################################################################################

my_year <- 2021

for (mm in c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")){
  
  
  # ------------ Load FELR -------------------- #
  
  # --- Data is split into two batches
  load(file = file.path(directory,paste0("10_data/101_output/s", mm,"_",my_year,"_oob_1.RData")))
  help_df_1 <- get(paste0("glide.chart.",my_year))
  # --- --- Reset directory
  directory <- directory_fix
  
  load(file = file.path(directory,paste0("10_data/101_output/s", mm,"_",my_year,"_oob_2.RData")))
  help_df_2 <- get(paste0("glide.chart.",my_year))
  # --- --- Reset directory
  directory <- directory_fix
  
  # --- Merge both "help_df_[1/2] to "CC" (=Compute Canada)
  CC_glide_chart <- data.frame(rbind(help_df_1[1:60,],help_df_2[61:nrow(help_df_2),]))
  
  
  # ------------ Load the Naive Benchmark & Save the glide.chart as "NB_glide_chart" -------------- #
  if (all(is.na(CC_glide_chart[,"OLS.trend.mse.in"]))){
    
    load(file = file.path(directory,paste0("10_data/101_output/NB_out/NB_s",mm,
                                           "_only",my_year,".RData")))
    NB_glide_chart <- get(paste0("glide.chart.",my_year))
    
    # --- Re-name the column
    colnames(NB_glide_chart)[which(colnames(NB_glide_chart) == "OLS-trend.mse.in")] <- "OLS.trend.mse.in"
    
    # --- --- Reset directory
    directory <- directory_fix
  } else {
    NB_glide_chart <- CC_glide_chart
  }
  
  
  # --- Collect the MSE --> Transform to RMSE & Create the plotting-dataframe
  plot.df <- data.frame("NB"=(NB_glide_chart$OLS.trend.mse.in)^0.5,
                        "FELR"=(CC_glide_chart$OLS.mse.in)^0.5)
  
  # --- Some Polishing-Up
  colnames(plot.df) <- gsub("\\-","\\.",colnames(plot.df))
  plot.df[,"time"] <- (-nrow(glide.chart)+1):0
  
  # --- Store the names of each Month --> there is also a built-in-function in R, but that took me a while to figure out...
  month.names <- c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")

  # --- Some Graphing-Layout specifications
  breaks <- seq(-120,0, by = 5)
  labels <- as.character(breaks)
  labels[!(breaks %in% seq(-120,0, by = 30))] <- ''
  tick.sizes <- rep(0.75, length(breaks))
  tick.sizes[!(breaks %in% seq(-120,0, by = 30))] <- 0.5
  tick.sizes.unit <- unit(x = tick.sizes,units = "cm")
  
  ylim.min <- 0   
  ylim.max <- 0.6   
  step.size <- 0.15
  ratio.display <- 16/9
  ratio.values <- (max(nrow(glide.chart))-min(0))/(ylim.max-(0))
  xlimit <- min(plot.df$time[1],-120)
  

  #   Plot the Data
  xlimit <- min(plot.df$time[1],-120)
  g1 <- ggplot(data = plot.df)
  g1 <- g1 +  geom_line(aes(x = time, y = NB, color="NB"), size = 2) +
    geom_line(aes(x = time, y = FELR, color="FELR"), size = 2)
  
  g1 <- g1 + scale_x_continuous(name = "", breaks = breaks, limits = c(xlimit, plot.df$time[nrow(plot.df)]), 
                                expand = c(0,0), labels = labels) +
    scale_y_continuous(name = "", breaks = seq(ylim.min+step.size, ylim.max, by = step.size), 
                       labels = c(sprintf("%.2f",seq(ylim.min+step.size, ylim.max, by = step.size))), 
                       limits = c(0,ylim.max), expand = c(0,0)) +
    labs(title = month.names[which(prep.data$mon == m.star)]) +
    coord_fixed(ratio=ratio.values/ratio.display) +
    theme_bw() +
    theme(legend.position="", legend.title=element_blank(), legend.text = element_text(size = 20),
          legend.direction = "horizontal", text = element_text(size = 20),
          plot.margin = ggplot2::margin(t=0.35, r=0.67, b=0, l=0.3, "cm"),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.ticks.x = element_line(size = tick.sizes),
          axis.text.x = element_text(size = 40),
          axis.text.y = element_text(size = 40),
          axis.title.y = element_text(margin = ggplot2::margin(t = 0, r = 0, b = 0, l = 0)),
          axis.ticks.length = unit(10, "mm"),
          plot.title = element_text(hjust = 0.5, size = 40)) +
    scale_color_manual(values = c("FELR"="darkorchid",
                                  "NB" = 'black')) +
    guides(col=guide_legend(nrow=2,byrow=TRUE))
    

  if (T){
    ggsave(file = paste0(directory,"/20_figures/RMSEs_",m.star,"_",my_year,"_v2.png"), 
           plot = g1, device = "png",
           width = 30, height = 20, units = "cm", dpi = 150)
  }
}
