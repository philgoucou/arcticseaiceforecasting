###################################################################################################################
#
#
#                                 Code to Run the Models
#
#
#
####################################################################################################################

rm(list = ls())

# ============================================== USER INTERACTION: Start ============================================== #

# --- Define your Directory:
directory <- "/Users/maximilian/Dropbox/ReplicationFiles"

# --- Which is your target-month/Y-Variable?
my_targets <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")

# --- For which Years do you want to run the loop? --> The year marks the LAST IN-SAMPLE year.
# --- --- if:     loop_years <- c(2011:2012)
# --- --- then:   Loop 1: Estimation based on data 1979-2011 ---> Prediction for 2012
# --- ---         Loop 2: Estimation based on data 1979-2012 ---> Prediction for 2013
loop_years <- c(2011:2020)

# ============================================== USER INTERACTION: End ============================================== #

# --- Load the Function-Calls for preparing the data-set
source(file.path(directory,"00_code/h003_prepdata.R"))
source(file.path(directory,"00_code/h002_rhscomponents.R"))
source(file.path(directory,"00_code/h002_buildxparty.R"))
source(file.path(directory,"00_code/h003_prepareFrank.R"))
source(file.path(directory,"00_code/MRF.R"))
source(paste(directory, '00_code/EM_sw.R', sep='/'))
source(paste(directory, '00_code/factor.R', sep='/'))

library(glmnet)
library(ranger)
library(caret)
library(gbm)
library(bagofprunes)
library(TVPRidge)
library(pracma)


# --- This starts the grand estimation loop for all the months specified in [my_targets]
for (ms in my_targets){   
  
  # --- The target month is re-named for compatibility
  m.star <- paste0("s",ms)
  
  # --- Some initializations
  list.dummy <- list(NA,NA,NA,NA,NA)
  names(list.dummy) <- c("singledays.lag", "singlemonths.lag", "XX.Days.start","XX.Days.end","prefix")
  oob.list <- list()
  
  # --- Loop through all the years: prediction will be made for year [yyy+1]
  for (yyy in loop_years){
    
    
    # ---------------------------- Model-Specification ---------------------------- #
    
    # ---------------------- Who is invited to your "Xparty"? ------------------------- #
    #
    #   00)   Which ICE-Variables do you want to include?
    #         a)  "SII" == Sea Ice Index (Extent) -- frequency = daily
    #         b)  "SIT" == PIOMAS thickness       -- frequency = daily
    #
    I.want.vars <- c("SII","SIT","CO2","AT")
    list.vars <- rep(list(list.dummy), times = length(I.want.vars))
    names(list.vars) <- I.want.vars
    
    #   00)   Do you want First-Differences of ICE-Variables? only possible for: CO2
    I.want.FD <- list()
    if ("CO2" %in% I.want.vars){
      I.want.FD$CO2 <- "yes"
    }
    if ("AT" %in% I.want.vars){
      I.want.FD$AT <- "yes"
    }
    #
    #   I)    Which "single.days" do you want to include? 
    #   --->  "single.days" are defined as days that occur at "singledays.lag" PRIOR to the day
    #         at which you are making the current prediction
    #   --->  the vector "singledays.lag" defines the number of "single.days" included in your model
    if ("SII" %in% I.want.vars){
      list.vars$SII$singledays.lag <- c(0:14)
      list.vars$SII$prefix <- ''  #   Do not touch
    }
    if ("SIT" %in% I.want.vars){
      list.vars$SIT$singledays.lag <- c(0:14)
      list.vars$SIT$prefix <- 'SIT.'  #   Do not touch
    }
    if ("CO2" %in% I.want.vars){
      list.vars$CO2$singledays.lag <- c()   # Do not touch
      list.vars$CO2$prefix <- 'CO2.'  #   Do not touch
    }
    if ("AT" %in% I.want.vars){
      list.vars$AT$singledays.lag <- c()   # Do not touch
      list.vars$AT$prefix <- 'AT.'  #   Do not touch
    }
    
    #   II)   Which "single.months" do you want to include?
    #   --->  "single.months" are defined as months that occur at "singlemonths.lag" PRIOR to the day
    #         at which you are making the current prediction
    #   --->  ATTENTION: the numbers in your vector "singlemonths.lag" will be automatically lagged by "1"!
    #                    hence: "singlemonths.lag = c(0)" will be the month PRIOR to the month 
    #                           in which you are currently standing
    #                   hence:  "singlemonths.lag = c(0)" would be the AR(1)-part...and so on
    
    if ("SII" %in% I.want.vars){
      #   --->  ATTENTION: MAXIMUM == 10
      list.vars$SII$singlemonths.lag <- c(0:10)
      
      if (any(list.vars$SII$singlemonths.lag > 10)){list.vars$SII$singlemonths.lag <- list.vars$SII$singlemonths.lag[-which(list.vars$SII$singlemonths.lag > 10)]}
    }
    if ("SIT" %in% I.want.vars){
      #   --->  ATTENTION: MAXIMUM == 9
      list.vars$SIT$singlemonths.lag <- c(0:9)
      
      if (any(list.vars$SIT$singlemonths.lag > 9)){list.vars$SIT$singlemonths.lag <- list.vars$SIT$singlemonths.lag[-which(list.vars$SIT$singlemonths.lag > 9)]}
    }
    if ("CO2" %in% I.want.vars){
      #   --->  ATTENTION: MAXIMUM == 8
      list.vars$CO2$singlemonths.lag <- c(0:8)
      
      if (any(list.vars$CO2$singlemonths.lag > 8)){list.vars$CO2$singlemonths.lag <- list.vars$CO2$singlemonths.lag[-which(list.vars$CO2$singlemonths.lag > 8)]}
    }
    if ("AT" %in% I.want.vars){
      #   --->  ATTENTION: MAXIMUM == 7
      list.vars$AT$singlemonths.lag <- c(0:7)
      
      if (any(list.vars$AT$singlemonths.lag > 7)){list.vars$AT$singlemonths.lag <- list.vars$AT$singlemonths.lag[-which(list.vars$AT$singlemonths.lag > 7)]}
    }
    
    
    #   III)  Which "averages of certain days" do you want to include? ---> "Days_XX.XX"
    #   --->  "Days_XX.XX" are defined as days that occur at "XX.Days.start" until "XX.Days.end" PRIOR to the day
    #         at which you are making the current prediction
    #   --->  ATTENTION:  if the vectors "XX.Days.start" and "XX.Days.end" do differ in length,
    #                     the code will only build a number of regressors equal to the length of the shorter vector
    #                     hence: length("Days_XX.XX") == min(length(XX.Days.start),length(XX.Days.end))
    if ("SII" %in% I.want.vars){
      list.vars$SII$XX.Days.start <- c(30, 5)
      list.vars$SII$XX.Days.end <- c(0, 0)
    }
    if ("SIT" %in% I.want.vars){
      list.vars$SIT$XX.Days.start <- c(30)
      list.vars$SIT$XX.Days.end <- c(0)
    }
    if ("CO2" %in% I.want.vars){
      list.vars$CO2$XX.Days.start <- c()  #  Do not touch
      list.vars$CO2$XX.Days.end <- c()    #  Do not touch
    }
    if ("AT" %in% I.want.vars){
      list.vars$AT$XX.Days.start <- c()  #  Do not touch
      list.vars$AT$XX.Days.end <- c()    #  Do not touch
    }
    
    #   IV)   Do you want to include a time-trend? Or even a quadratic?
    I.want.trend <- "yes"
    I.want.trendQ <- "no"
    
    #   V)    Do you want summer/winter dummies?
    I.want.summerD <- "yes"
    I.want.winterD <- "yes"
    
    #   VI)    Do you want any monthly dummies? ---> an arbitrary vector of numbers between 1:12 
    monthlyD <- c()
    
    #   VII)  If you only want to include a certain subset of "synthetic months", specify them here
    #         ---> please insert integers: JAN = 1, FEB = 2, ..., DEC = 12
    I.want.subset.of.syn.months <- c() #c(7,8,9) #c(6,7,8,9)
    if (!is.null(I.want.subset.of.syn.months)){
      if (length(which(I.want.subset.of.syn.months %in% c(11,12,1,2,3))) == 0 | all(I.want.subset.of.syn.months %in% c(11,12,1,2,3)) ){
        I.want.winterD <- "no"
      }
      if ( length(which(I.want.subset.of.syn.months %in% c(6,7,8,9))) == 0 | all(I.want.subset.of.syn.months %in% c(6,7,8,9))){
        I.want.summerD <- "no"
      }
      if (length(I.want.subset.of.syn.months) > 0){
        monthlyD <- monthlyD[which(monthlyD %in% I.want.subset.of.syn.months)]
      }
    }
    #   VIII)   Specify the Years of your Training-Sample:
    train.years <- seq(1979,yyy, by = 1)  
    #
    #   IX)     Specify the Years of your Testing-Sample:  
    #           BEWARE: you will also create monthly Figure(s) for each year in "test.years" if you start the loop
    test.years <- seq(yyy+1,yyy+1, by = 1)  
    
    # Feature enginerring yes/no
    FE=TRUE
    howmanyout=I(I.want.trend=='yes')+I(I.want.trendQ=='yes')+I(I.want.summerD=='yes')+I(I.want.winterD=='yes')
    
    #
    #   X)    Do you want "synthetic observations" or just the "real observations"?
    I.want.realobs <- "yes"
    if (I.want.realobs == "yes"){
      I.want.summerD <- "no"
      I.want.winterD <- "no"
      monthlyD <- c()
      I.want.subset.of.syn.months <- c()
      #FE=FALSE
    }
    #
    # ------------------ CONGRATULATIONS! You're done with USER INTERACTION !   ---------------- #
    
    
    
    # --- Some preliminary data-preparation: 
      
    #       I)    "ICE_data":         Load your dataset ---> add: Dummies (summer, winter, monthly); Trends (linear, quadratic)
    #       II)   "ICE_data.true":    a frozen "ICE_data" after having included Dummies & Trends
    #       III)  "glide.chart":      a storage for final day-by-day results (point forecast + SEs)
    #       IV)   "help_df":          a storage that identifies the daily varying regression-model
    #       V)    "list_XX.XX":       a storage that helps creating the "averages" over certain days 
    #                                 (see "III)" in the specification above)
    #       VI)   "densities.daily":  a storage for final day-by-day densities (needed for 3D figures)
    #       VII)  "mon":              a sequence of months
    prep.data <- h003_prepdata(directory=directory, m.star=m.star, I.want.vars, list.vars, I.want.FD)
    
    # You might have decided against choosing the "synthetic" data, and you want the "real" observations instead:
    if (I.want.realobs == "yes"){
      real.obs <- as.matrix(read.csv(file.path(directory,paste0("10_data/SII_processed_nomissing_realobs.csv")))[,1])
      colnames(real.obs) <- "Year"
      
      if ("SII" %in% I.want.vars){
        SII.real <- read.csv(file.path(directory,paste0("10_data/SII_processed_nomissing_realobs.csv")))
        real.obs <- cbind(real.obs,SII.real[,-c(1)])
      }
      if ("SIT" %in% I.want.vars){
        SIT.real <- read.csv(file.path(directory,paste0("10_data/SIT_processed_nomissing_realobs.csv")))
        real.obs <- cbind(real.obs,SIT.real[,-c(1)])
      }
      if ("CO2" %in% I.want.vars){
        if (I.want.FD$CO2 == "yes"){
          CO2.real <- read.csv(file.path(directory,paste0("10_data/CO2_processed_nomissing_realobs_FD.csv")))
        } else {  
          CO2.real <- read.csv(file.path(directory,paste0("10_data/CO2_processed_nomissing_realobs.csv")))
        }
        real.obs <- cbind(real.obs,CO2.real[,-c(1)])
      }
      if ("AT" %in% I.want.vars){
        if (I.want.FD$AT == "yes"){
          AT.real <- read.csv(file.path(directory,paste0("10_data/AT_processed_nomissing_realobs_FD.csv")))
        } else {  
          AT.real <- read.csv(file.path(directory,paste0("10_data/AT_processed_nomissing_realobs.csv")))
        }
        real.obs <- cbind(real.obs,AT.real[,-c(1)])
      }
      
      colnames(real.obs) <- c("Year", paste0("s",colnames(real.obs)[2:ncol(real.obs)]))
      
      add.df <- data.frame("trend" = seq(1,nrow(real.obs)), "month" = NA ,"summer" = NA, "winter" = NA)
      add.df[, paste0("D",c(1:12))] <- NA
      
      prep.data$ICE_data <- cbind(real.obs, add.df)
      prep.data$ICE_data.true <- prep.data$ICE_data
      
    }
    

    #   Create a "glide.chart" for each year in "test.years"
    for (yy in test.years){
      assign(paste0("glide.chart.",yy), prep.data$glide.chart)
    }
    
    #   Create a "densities.daily" for each year in "test.years"
    for (yy in test.years){
      assign(paste0("densities.daily.",yy), prep.data$densities.daily)
    }
    
    
    
    # ------------- Create storage matrices
    glide.chart <- prep.data$glide.chart
    glide.chart <- cbind(glide.chart,data.frame("MRF.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                "MRF_Pocket.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                "MRF.trend.MA5.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                "FELR.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                "FELR_Pocket.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                "OLS-trend.mse.in" = rep(NA, times = nrow(glide.chart)),
                                                check.names = F))
    
    
    densities.daily <- prep.data$densities.daily
    ERR=array(NA,dim=c(40,length(test.years),nrow(glide.chart)))
    
    oob.storage <- setNames(rep(list(data.frame(cbind(trend=c(1:42),
                                                      matrix(NA,nrow=2020-1978,ncol=nrow(glide.chart))))),times=12),
                            c("MRF","MRF_Pocket","FELR","FELR_Pocket","OLS-trend"))
    oob.list[[as.character(yyy+1)]] <- oob.storage
    

    # --- Loop over each day
    for (r in 1:nrow(glide.chart)){ 
      
      print(paste0("Year of Forecast: ", yyy+1, " --- Month: ",substr(m.star,2,nchar(m.star)), " --- Day: ", r))
      
      #  --- Create components, necessary for the regression model:
      #       I)    "single.days.vec":      A vector containing all the single-day-regressors
      #       II)   "single.months.vec":    A vector containing all the single-month-regressors
      #       III)  "Days_XX.XX":           A string containing the "averages" across days 
      #       IV)   "Xparty":               A string containing your regression formula
      rhs.components <- h002_rhscomponents(r = r, month.day.index=prep.data$month.day.index, mon = prep.data$mon,
                                           help_df=prep.data$help_df, 
                                           list.vars, 
                                           I.want.trend=I.want.trend, I.want.trendQ=I.want.trendQ, 
                                           I.want.summerD=I.want.summerD, I.want.winterD=I.want.winterD, monthlyD=monthlyD)
      
      #   --- Build your "Xparty", i.e. the data for the RHS of your model 
      Xparty.df <- h002_buildxparty(m.star=m.star,mon=prep.data$mon, today.month = rhs.components$today.month,
                                    ICE_data=prep.data$ICE_data,
                                    single.days.vec=rhs.components$single.days.vec,
                                    single.months.vec=rhs.components$single.months.vec,
                                    list_XX.XX=prep.data$list_XX.XX, 
                                    Days_XX.XX=rhs.components$Days_XX.XX,
                                    I.want.trend, I.want.trendQ,
                                    I.want.summerD, I.want.winterD,
                                    monthlyD, I.want.realobs,I.want.subset.of.syn.months,
                                    list.vars)
      
      
      # --- Define your 'X'
      X <- as.matrix(Xparty.df[which(Xparty.df$Year %in% train.years),4:ncol(Xparty.df)])
      
      # --- Define your 'Y'
      if (length(I.want.subset.of.syn.months) > 0){
        Y <- as.matrix(data.frame("Y" = prep.data$ICE_data[which(prep.data$ICE_data$Year %in% train.years &
                                                                   prep.data$ICE_data$month %in% I.want.subset.of.syn.months),
                                                           m.star]))
      } else{
        Y <- as.matrix(data.frame("Y" = prep.data$ICE_data[which(prep.data$ICE_data$Year %in% train.years),m.star]))
      }
      
      # --- Define your 'Xtest' ---> do not include the constant!
      Xtest <- as.matrix(Xparty.df[which(Xparty.df$Year %in% test.years),4:ncol(Xparty.df)])
      
      # --- Define your 'Ytest'
      if (length(I.want.subset.of.syn.months) > 0){
        Ytest <- as.matrix(data.frame("Y" = prep.data$ICE_data[which(prep.data$ICE_data$Year %in% test.years &
                                                                       prep.data$ICE_data$month %in% I.want.subset.of.syn.months),
                                                               m.star]))
      } else{
        Ytest <- as.matrix(data.frame("Y" = prep.data$ICE_data[which(prep.data$ICE_data$Year %in% test.years),m.star]))
      }
      
      # --- Define your regression-formula --> not in use
      reg.form <- paste0("Y ~ ", rhs.components$Xparty)
      
      
      
      # --- Imputation of Missing Values via an Expectation-Maximization algorithm ---> Credits to: Stephane Surprenant
      if(ncol(X)>10){X  <- EM_sw(data=X,n=8,it_max=1000)$data}
      
      # --- Feature engineering
      if(FE==TRUE){
        out=((ncol(X)-howmanyout):ncol(X))
        stuff  <- EM_sw(data=X[,-out],n=5,it_max=1000)
        facs=stuff$factors               
        colnames(facs)=paste('F',c(1:5),sep='')
        if (length(test.years) == 1 & I.want.realobs == "yes"){
          Xtest_std = t(as.matrix(Xtest[,-out]))
        } else{
          Xtest_std = Xtest[,-out]
        }
        for(jj in 1:ncol(Xtest_std)){Xtest_std[,jj]=(Xtest[,jj]-mean(X[,jj]))/sd(X[,jj])}
        facs.out=Xtest_std%*%stuff$lambda/ncol(Xtest_std)
        colnames(facs.out)=paste('F',c(1:5),sep='')
        X=cbind(X,facs)
        Xtest=cbind(Xtest,facs.out)
      }
      
      datin = cbind(Y,X) 
      datin=datin[complete.cases(datin),]
      Y=matrix(datin[,1])
      colnames(Y) <- 'Y'
      X=datin[,-c(1)]
      
      
    
      # --- Further Storage Initialization
      Rsq_in <- data.frame()
      Rsq_out <- data.frame()
      m=0
      err=array(NA,dim=c(40,length(Ytest)))
      fcast.comb.mse.weights <- array(NA,dim=c(4,1))
      r.squared.fair = function(pred, actual,y.is) {
        rss <- sum((actual-pred)^2)
        tss <- sum((actual-mean(y.is))^2)
        rsq=1-rss/tss
        return(rsq)
      }
      dataset='ICE'
      train_data=as.data.frame(cbind(Y,X))
      test_data=as.data.frame(cbind(Ytest,Xtest))
      rownames(train_data)=c()
      rownames(test_data)=c()
      colnames(test_data)[1]= colnames(train_data)[1]
      form=Y~.
      
      
      # -------- Prepare the data for FELR   ---> FELR model is based on "real observations"! ---- START
      
      #   You can set: "include.quadratic = [yes/no]"
      Franks.model <- h003_prepareFrank(directory, prep.data, I.want.realobs, I.want.subset.of.syn.months, r, m.star,
                                        include.quadratic = "no")
      
      # --- Create the training- and 'test'-matrices
      train_data.Frank=as.data.frame(cbind(Franks.model$Y.Frank,Franks.model$X.Frank))
      colnames(train_data.Frank)[1]='Y'
      test_data.Frank=as.data.frame(cbind(Franks.model$Ytest.Frank,Franks.model$Xtest.Frank))
      rownames(train_data.Frank)=c()
      rownames(test_data.Frank)=c()
      colnames(test_data.Frank)[1]= colnames(train_data.Frank)[1]
      
      # -------- Prepare the data for Frank's model   ---> Frank's model is based on "real observations"! ---- End
      
      
      # ----------------------- ----------------------- ----------------------- ----------------------- ----------------------- 
      #
      #         Now it's time to run the Models!
      #
      # ----------------------- ----------------------- ----------------------- ----------------------- ----------------------- 



          # ------------------------------------   FEML  -------------------------------------------  #
        
          # --- At which position (column) in the data matrix are our regressors located?
          z.pos = c()
          if (I.want.realobs == "yes"){
            for(j in 2:length(colnames(train_data.Frank))){
              add.this=which(colnames(train_data)==colnames(train_data.Frank)[j])
              z.pos=append(z.pos,add.this)
            }
          } else {
            for(j in 1:length(Franks.model$Franks.regressors)){
              add.this=which(colnames(train_data)==Franks.model$Franks.regressors[j])
              z.pos=append(z.pos,add.this)
            }
          }
          position.of.X=z.pos
          
          # --- Which rows cover the out-of-sample period?
          position.oos <- c((nrow(train_data)+1)):((nrow(train_data) + nrow(test_data)))
          
          # --- Estimate
          out <- MRF(data=as.matrix(rbind(train_data,test_data)),minsize=5,
                     min.leaf.frac.of.x=1, y.pos=1,resampling.opt = 2,B=60,
                     x.pos = position.of.X,
                     subsampling.rate=0.9,
                     oos.pos=position.oos,mtry.frac=.3,block.size=2+22*I(I.want.realobs=='no'),
                     ridge.lambda=1,rw.regul=0.25,cheap.look.at.GTVPs=TRUE,
                     prior.mean=coef(lm(as.formula(form),data = train_data[,c(z.pos)])),
                     prior.var=1/c(0.01,0.25,rep(1,length(position.of.X)-1)),printb=FALSE)
          
          # --- Predict: out-of-sample
          pred.out <- out$pred
          
          m=m+1
          # --- Store: OOS-Forecast-Error
          err[m,1:length(Ytest)]=out.error <- pred.out-Ytest
          
          # --- Store: R^2
          Rsq_out[dataset, 'FEML'] <-  r.squared.fair(pred.out, Ytest, Y)
          
          # --- Store: OOS-Prediction
          glide.chart[r,'FEML'] <- pred.out[length(pred.out)]
          
          # --- Store: out-of-sample prediction error
          prediction.error.oos <- sd(out$pred.ensemble, na.rm = T)
          
          # --- Store: Residuals (of out-of-bag samples)
          res <- out$YandX[-position.oos,1] - 
            apply((cbind(rep(1,times=nrow(train_data)),out$YandX[-position.oos,-1]) * out$betas[-position.oos,]),1,sum)
          
          # --- Store: Out-of-Bag Prediction Error 
          prediction.error.oob <- (t(res) %*% res) / length(res)
          
          # --- Store: Point-Forecast +- 2*RMSE (oos)
          densities.daily[r,'FEML.point'] <- pred.out[length(pred.out)]
          densities.daily[r,'FEML.SE2oos_low'] <- pred.out[length(pred.out)] - 2*prediction.error.oos
          densities.daily[r,'FEML.SE2oos_up'] <- pred.out[length(pred.out)] + 2*prediction.error.oos
          
          # --- Store: Point-Forecast +- 2*RMSE (out-of-bag)
          densities.daily[r,'FEML.SE2oob_low'] <- pred.out[length(pred.out)] - 2*prediction.error.oob
          densities.daily[r,'FEML.SE2oob_up'] <- pred.out[length(pred.out)] + 2*prediction.error.oob
          
          # --- Store: MSE (of out-of-bag error)
          glide.chart[r,'FEML.mse.in'] <- prediction.error.oob
          
          # --- Store: Out-Of-Bag Errors
          non.na.val <- oob.storage$MRF$trend[which(oob.storage$MRF$trend %in% train_data$trend)]
          oob.list[[as.character(yyy+1)]][["FEML"]][non.na.val,r+1] <- res
              
            
            
            
          # -----------------------------------------   Pocket FEML  --------------------------------------------------  # 
          
          # --- At which position (column) in the data matrix are our regressors located?
          position.of.X.TT=c(which(colnames(train_data)==Franks.model$rhs.components.Frank$single.days.vec),
                             which(colnames(train_data)=="trend"))
          
          # --- Estimate
          out <- MRF(data=as.matrix(rbind(train_data,test_data)),minsize=5,
                     min.leaf.frac.of.x=1, y.pos=1,resampling.opt = 2,B=60,
                     x.pos = position.of.X.TT,
                     subsampling.rate=0.9,
                     oos.pos=position.oos,mtry.frac=1,block.size=2+22*I(I.want.realobs=='no'),
                     ridge.lambda=1,rw.regul=0.25,cheap.look.at.GTVPs=TRUE,
                     prior.mean=coef(lm(as.formula(form),data = train_data[,c(1,position.of.X.TT)])),
                     prior.var=1/c(0.01,0.25,rep(1,length(position.of.X.TT)-1)),printb=FALSE)
          
          # --- Predict: out-of-sample
          pred.out <- out$pred
          
          m=m+1
          # --- Store: OOS-Forecast-Error
          err[m,1:length(Ytest)]=out.error <- pred.out-Ytest
          Rsq_out[dataset, 'FEML_Pocket'] <-  r.squared.fair(pred.out, Ytest, Y)
          
          # --- Store: OOS-Prediction
          glide.chart[r,'FEML_Pocket'] <- pred.out[length(pred.out)]
          
          # --- Store: out-of-sample prediction error
          prediction.error.oos <- sd(out$pred.ensemble, na.rm = T)
          res <- out$YandX[-position.oos,1] - 
            apply((cbind(rep(1,times=nrow(train_data)),out$YandX[-position.oos,-1]) * out$betas[-position.oos,]),1,sum)
          
          # --- Store: Out-of-Bag Prediction Error
          prediction.error.oob <- (t(res) %*% res) / length(res)
          
          # --- Store: Point-Forecast +- 2*RMSE (oos)
          densities.daily[r,'FEML_Pocket.point'] <- pred.out[length(pred.out)]
          densities.daily[r,'FEML_Pocket.SE2oos_low'] <- pred.out[length(pred.out)] - 2*prediction.error.oos
          densities.daily[r,'FEML_Pocket.SE2oos_up'] <- pred.out[length(pred.out)] + 2*prediction.error.oos
          
          # --- Store: Point-Forecast +- 2*RMSE (out-of-bag)
          densities.daily[r,'FEML_Pocket.SE2oob_low'] <- pred.out[length(pred.out)] - 2*prediction.error.oob
          densities.daily[r,'FEML_Pocket.SE2oob_up'] <- pred.out[length(pred.out)] + 2*prediction.error.oob
          
          # --- Store: MSE (of out-of-bag error)
          glide.chart[r,'FEML_Pocket.mse.in'] <- prediction.error.oob
          
          # --- Store: Out-Of-Bag Errors
          non.na.val <- oob.storage$MRF$trend[which(oob.storage$MRF$trend %in% train_data$trend)]
          oob.list[[as.character(yyy+1)]][["FEML_Pocket"]][non.na.val,r+1] <- res
            
            
            
          
        # ----------------------------- FELR: Y ~ c + trend + Last_Month + Last_XXDays+ today  ------------------------ #
          
        # --- Build the training-matrix: [Y,X]
        Frank.train <- data.frame(cbind(Franks.model$Y.Frank,Franks.model$X.Frank))
        colnames(Frank.train) <- c("Y",colnames(Franks.model$X.Frank))
        
        # --- Estimate
        ols.reg <- lm(as.formula(paste0("Y ~ ",paste0(colnames(Franks.model$X.Frank), collapse = " + "))),
                      data = Frank.train)
        
        # --- Prepare testing-matrix: [Y,X]
        Frank.test <- data.frame(cbind(Franks.model$Xtest.Frank))
        colnames(Frank.test) <- c(colnames(Franks.model$Xtest.Frank))
        
        # --- Predict: in-sample
        pred.in <- predict(ols.reg, data.frame(Franks.model$X.Frank))
        pred.in.ols <- pred.in
        
        # --- Predict: out-of-sample
        pred.out.ols=predict(ols.reg, Frank.test)
        
        
        m=m+1
        # --- Store: OOS-Forecast-Error
        err[m,1:length(Ytest)]= pred.out.ols-Ytest
        
        # --- Store: R^2
        Rsq_out[dataset, "FELR"] <- r.squared.fair(pred.out.ols, Franks.model$Ytest.Frank,Franks.model$Y.Frank)
        
        # --- Store: OOS-Prediction
        glide.chart[r,'FELR'] <- pred.out.ols[length(pred.out.ols)]
        
        # --- Store: MSE
        glide.chart[r,'FELR.mse.in'] <- (t(ols.reg$residuals) %*% ols.reg$residuals) / length(ols.reg$residuals)
        
        # --- Store: Point-Forecast +- 2*RMSE
        prediction.error <- (sum((ols.reg$residuals)^2)/length(ols.reg$residuals))^0.5
        densities.daily[r,'FELR.point'] <- pred.out.ols[length(pred.out.ols)]
        densities.daily[r,'FELR.SE2_low'] <- pred.out.ols[length(pred.out.ols)] - 2*prediction.error
        densities.daily[r,'FELR.SE2_up'] <- pred.out.ols[length(pred.out.ols)] + 2*prediction.error
        
        # --- Store: Residuals
        non.na.val <- oob.storage$MRF$trend[which(oob.storage$MRF$trend %in% Frank.train$trend)]
        oob.list[[as.character(yyy+1)]][["FELR"]][non.na.val,r+1] <- ols.reg$residuals
        
        
        #  ------------------------------------------   Pocket FELR: Y ~ c + trend + today  ------------------------------------------ #
        
        # --- Build the training-matrix: [Y,X]
        Frank.train <- data.frame(cbind(Franks.model$Y.Frank,Franks.model$X.Frank))
        colnames(Frank.train) <- c("Y",colnames(Franks.model$X.Frank))
        
        # --- Since "Pocket FELR" does not require the regressor "Last_Month", 
        #     the estimation for some months can already start in the very first year
        if (nrow(Frank.train) < length(c(prep.data$ICE_data.true$Year[1]:yyy))){
          help_df <- data.frame("Y"=rep(NA,times=length(c(prep.data$ICE_data.true$Year[1]:yyy))),
                                "trend"=c(1:length(c(prep.data$ICE_data.true$Year[1]:yyy))))
          help_df$Y[which(help_df$trend %in% Frank.train$trend)] <- Frank.train$Y
          help_df[which(help_df$trend %in% Frank.train$trend),Franks.model$rhs.components.Frank$single.days.vec] <- Frank.train[,Franks.model$rhs.components.Frank$single.days.vec]
          
          
          # --- Which is/are the missing rows?
          miss_row <- which(is.na(help_df$Y))
          # --- Fill the missing values
          help_df$Y[miss_row] <- prep.data$ICE_data.true[miss_row,m.star]
          help_df[miss_row,Franks.model$rhs.components.Frank$single.days.vec] <- prep.data$ICE_data.true[miss_row,Franks.model$rhs.components.Frank$single.days.vec]
          
          
          # --- If there are potential NAs still, remove them (and the whole procedure was unnecessary)
          help_df <- na.omit(help_df)
          
          # --- Build the new training-set:
          Frank.train <- help_df
        }  
            
        # --- Estimate
        ols.reg.trend.today <- lm(as.formula(paste0("Y ~ trend + ", 
                                                    Franks.model$rhs.components.Frank$single.days.vec)),data = Frank.train)
        
        # --- Prepare testing-matrix: [Y,X]
        Frank.test <- data.frame(cbind(Franks.model$Xtest.Frank))
        colnames(Frank.test) <- c(colnames(Franks.model$Xtest.Frank))
        
        # --- Predict: in-sample
        pred.in.trend.today <- predict(ols.reg.trend.today, Frank.train)
        
        # --- Predict: out-of-sample
        pred.out.trend.today=predict(ols.reg.trend.today, Frank.test)
        

        m=m+1
        # --- Store: OOS-Forecast-Error
        err[m,1:length(Ytest)]= pred.out.trend.today-Ytest
        
        # --- Store: R^2
        Rsq_out[dataset, "FELR_Pocket"] <- r.squared.fair(pred.out.trend.today, Franks.model$Ytest.Frank,Franks.model$Y.Frank)
        
        # --- Store: OOS-Prediction
        glide.chart[r,'FELR_Pocket'] <- pred.out.trend.today[length(pred.out.trend.today)]
        
        # --- Store: MSE
        glide.chart[r,'FELR_Pocket.mse.in'] <- (t(ols.reg.trend.today$residuals) %*% ols.reg.trend.today$residuals) / length(ols.reg.trend.today$residuals)
        
        # --- Store: Point-Forecast +- 2*RMSE
        prediction.error <- (sum((ols.reg.trend.today$residuals)^2)/length(ols.reg.trend.today$residuals))^0.5
        densities.daily[r,'FELR_Pocket.point'] <- pred.out.trend.today[length(pred.out.trend.today)]
        densities.daily[r,'FELR_Pocket.SE2_low'] <- pred.out.trend.today[length(pred.out.trend.today)] - 2*prediction.error
        densities.daily[r,'FELR_Pocket.SE2_up'] <- pred.out.trend.today[length(pred.out.trend.today)] + 2*prediction.error
        
        # --- Store: Residuals
        non.na.val <- oob.storage$MRF$trend[which(oob.storage$MRF$trend %in% Frank.train$trend)]
        oob.list[[as.character(yyy+1)]][["FELR_Pocket"]][non.na.val,r+1] <- ols.reg.trend.today$residuals
        
        
        #  ---------------------------   Naive Benchmark: Y ~ c + trend  ------------------------- #
        
        # --- Build the training-matrix: [Y,X]
        Frank.train <- data.frame(cbind(Franks.model$Y.Frank,Franks.model$X.Frank))
        colnames(Frank.train) <- c("Y",colnames(Franks.model$X.Frank))
        
        # --- Since the "Naive Benchmark" does not require the regressor "Last_Month", 
        #     the estimation for some months can already start in the very first year
        if (Frank.train$trend[1] == 2){
          Frank.train <- setNames(data.frame(rbind(rep(NA, times=ncol(Frank.train)),Frank.train)),colnames(Frank.train))
          Frank.train$Y[1] <- prep.data$ICE_data.true[1,m.star]
          Frank.train$trend[1] <- 1
        }
        if (nrow(Frank.train) < length(c(prep.data$ICE_data.true$Year[1]:yyy))){
          help_df <- data.frame("Y"=rep(NA,times=length(c(prep.data$ICE_data.true$Year[1]:yyy))),
                                "trend"=c(1:length(c(prep.data$ICE_data.true$Year[1]:yyy))))
          help_df$Y[which(help_df$trend %in% Frank.train$trend)] <- Frank.train$Y
          
          # --- Which is/are the missing rows?
          miss_row <- which(is.na(help_df$Y))
          # --- Fill the missing values
          help_df$Y[miss_row] <- prep.data$ICE_data.true[miss_row,m.star]
          
          # --- If there are potential NAs still, remove them (and the whole procedure was unnecessary)
          help_df <- na.omit(help_df)
          
          # --- Build the new training-set:
          Frank.train <- help_df
        }
        
        # --- Estimate
        ols.trend <- lm(as.formula(paste0("Y ~ trend")),data = Frank.train)
        
        # --- Prepare testing-matrix: [Y,X]
        Frank.test <- data.frame(cbind(Franks.model$Xtest.Frank))
        colnames(Frank.test) <- colnames(Franks.model$Xtest.Frank)
        
        # --- Predict: in-sample
        pred.in.trend <- predict(ols.trend, Frank.train)
        
        # --- Predict: out-of-sample
        pred.out.trend <- predict(ols.trend, Frank.test)
        
        
        m=m+1
        # --- Store: OOS-Forecast-Error
        err[m,1:length(Ytest)]= pred.out.trend-Ytest
        
        # --- Store: R^2
        Rsq_out[dataset, "OLS-trend"] <- r.squared.fair(pred.out.trend, Franks.model$Ytest.Frank,Franks.model$Y.Frank)
        
        # --- Store: OOS-Prediction
        glide.chart[r,'OLS-trend'] <- pred.out.trend[length(pred.out.trend)]
        
        # --- Store: MSE
        glide.chart[r,'OLS-trend.mse.in'] <- (t(ols.trend$residuals) %*% ols.trend$residuals) / length(ols.trend$residuals)
        
        # --- Store: Point-Forecast +- 2*RMSE
        prediction.error <- (sum((ols.trend$residuals)^2)/length(ols.trend$residuals))^0.5
        densities.daily[r,'OLS-trend.point'] <- pred.out.trend[length(pred.out.trend)]
        densities.daily[r,'OLS-trend.SE2_low'] <- pred.out.trend[length(pred.out.trend)] - 2*prediction.error
        densities.daily[r,'OLS-trend.SE2_up'] <- pred.out.trend[length(pred.out.trend)] + 2*prediction.error
        
        # --- Store: Residuals
        non.na.val <- oob.storage$MRF$trend[which(oob.storage$MRF$trend %in% Frank.train$trend)]
        oob.list[[as.character(yyy+1)]][["OLS-trend"]][non.na.val,r+1] <- ols.trend$residuals
        
          
        # ==================================== ESTIMATION DONE! ==================================== #  

        # --- Add the formula ---> just for checking
        glide.chart$formula[r] <- reg.form
        
        # --- Collect the OOS-Errors
        ERR[,,r]=err

        
      
    } # This ends: for (r in 1:nrow(glide.chart)){
    
    assign(paste0("glide.chart.",yyy+1),glide.chart)
    assign(paste0("densities.daily.",yyy+1),densities.daily)
      
        
    
    
    
    
    
    if (length(test.years) == 1){
      
      MSE = sqrt(ERR[1:40,,]^2)
      
      assign(paste0("MSE_", test.years),MSE)
      assign(paste0("ERR_", test.years),ERR)

    } else{
      
      MSE = sqrt(apply(ERR[1:40,,]^2,c(1,3),mean))
      
      assign(paste0("MSE_", test.years[1],"_",test.years[length(test.years)]),MSE)
      assign(paste0("ERR_", test.years[1],"_",test.years[length(test.years)]),ERR)

    }
    
    
    if (length(test.years) == 1){
      
      MAE = abs(ERR[1:40,,])
      assign(paste0("MAE_", test.years),MAE)
      
    } else {
      
      MAE = (apply(abs(ERR[1:40,,]),c(1,3),mean))
      assign(paste0("MAE_", test.years[1],"_",test.years[length(test.years)]),MAE)
      
    }
    
    # --- Define some colors --> for plotting later on
    library(RColorBrewer)
    n <- 40
    qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
    col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
    
    # ========================================================================================================= #
    #             Export 
    # ========================================================================================================= #
    save.image(file = file.path(directory,paste0("10_data/101_output/",m.star,"_",yyy,".RData")))
    
    
  } #This ends: for (yyy in loop_years){
  
  
  # --- Next month [ms]
  
} # This ends: for (ms in c(...)){}



