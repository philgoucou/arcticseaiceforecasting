preprocessSIT <- function(directory){
  
  mon <- c("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC")
  day <- c(31,59,90,120,151,181,212,243,273,304,334,365)
  
  SIT_df <- read.csv(file.path(directory,"SIT_Daily.csv"))
  
  # Add "Month" & "Day"
  for (mm in mon){
    
    if (mm == "JAN"){
      mm_day.range <- 1:day[1]
    } else{
      mm_day.range <- (day[which(mon == mm)-1] + 1):day[which(mon == mm)]
    }
    
    SIT_df[which(SIT_df$Year.Day %in% mm_day.range),"Month"] <- which(mon == mm)
    
    # Maybe there is a Month for which NOT ALL DAYS have data!
    notfullmonth <- length(which(SIT_df$Year.Day %in% mm_day.range)) / length(mm_day.range)
    if (notfullmonth > as.integer(notfullmonth)){
      SIT_df[which(SIT_df$Year.Day %in% mm_day.range)[1:(as.integer(notfullmonth)*length(mm_day.range))],"Day"] <- 1:length(mm_day.range)
      SIT_df[which(SIT_df$Year.Day %in% mm_day.range)[(as.integer(notfullmonth)*length(mm_day.range)+1):length(which(SIT_df$Year.Day %in% mm_day.range))],"Day"] <- 1:(length(which(SIT_df$Year.Day %in% mm_day.range)) - as.integer(notfullmonth)*length(mm_day.range))
    } else{
      SIT_df[which(SIT_df$Year.Day %in% mm_day.range),"Day"] <- 1:length(mm_day.range)
    }
  }

  return(SIT_df)
  
}  
