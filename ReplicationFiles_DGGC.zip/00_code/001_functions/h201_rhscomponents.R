h201_rhscomponents <- function(r, month.day.index, mon,
                               help_df, singledays.lag, singlemonths.lag,
                              XX.Days.start, XX.Days.end, I.want.trend, I.want.trendQ, 
                              I.want.summerD, I.want.winterD, monthlyD){
  
  #   Create the Formula for the regression
  today.day <- month.day.index$day[which(month.day.index$month == as.character(help_df$This.Month[r]) & 
                                           month.day.index$day == help_df$Day.This.Month[r])]
  today.month <- as.character(month.day.index$month[which(month.day.index$month == as.character(help_df$This.Month[r]) 
                                                          & month.day.index$day == help_df$Day.This.Month[r])])
  row.today <- which(month.day.index$month == today.month & month.day.index$day == today.day)
  
  #   Shift the month-vector, such that "today.month" is at position 12
  if (today.month == "sDEC"){
    mon.t <- mon[-(which(mon == today.month))]
    mon.t1 <- c()
  } else if (today.month == "sJAN"){
    mon.t <- c()
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  } else  {
    mon.t <- mon[1:(which(mon == today.month) - 1)]
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  }
  mon.shifted <- c(mon.t1, mon.t, today.month)
  
  #   -------- BUILD THE FORMULA!    --------------------------------------------------------------------------        
  
  #   "singledays.lag"
  single.days <- ""
  single.days.vec <- NA
  if (length(singledays.lag) > 0){
    for (ll in 1:length(singledays.lag)){
      single.days <- paste0(single.days,
                            month.day.index$month[row.today - singledays.lag[ll]], 
                            month.day.index$day[row.today - singledays.lag[ll]], "_", 
                            month.day.index$day[row.today - singledays.lag[ll]], " + ")
      single.days.vec[length(single.days.vec) + 1] <- paste0(month.day.index$month[row.today - singledays.lag[ll]], 
                                                             month.day.index$day[row.today - singledays.lag[ll]], "_", 
                                                             month.day.index$day[row.today - singledays.lag[ll]])
    }
    single.days.vec <- na.omit(single.days.vec)
  }
  
  #   "singlemonths.lag"
  single.months <- ""
  single.months.vec <- NA
  if (length(singlemonths.lag) > 0){
    for (ll in 1:length(singlemonths.lag)){
      last.month_r <- as.character(month.day.index$month[which(month.day.index$month == as.character(help_df$Last.Month[r]) 
                                                               & month.day.index$day == help_df$Day.This.Month[r])])
      if (length(last.month_r) == 0){
        last.month_r <- unique(as.character(month.day.index$month[which(month.day.index$month == as.character(help_df$Last.Month[r]))]))
      }
      #single.months <- paste0(single.months, mon.shifted[which(mon.shifted == today.month) - 1 - singlemonths.lag[ll]], " + ")
      #single.months.vec[length(single.months.vec) + 1] <- paste0(mon.shifted[which(mon.shifted == today.month) - 1 - 
      #                                                                        singlemonths.lag[ll]])
      
      single.months <- paste0(single.months, mon.shifted[which(mon.shifted == last.month_r) - singlemonths.lag[ll]], " + ")
      single.months.vec[length(single.months.vec) + 1] <- paste0(mon.shifted[which(mon.shifted == last.month_r) - 
                                                                              singlemonths.lag[ll]])
    }
    single.months.vec <- na.omit(single.months.vec)
  }
  
  #   "Days_XX.XX" ---> check if "last.XX.days" coincides with "last.month"
  days <- c(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  days.in_today.month <- days[which(mon == today.month)]
  
  if (today.day == days.in_today.month & any(XX.Days.start-XX.Days.end == days.in_today.month)){
    pos.remove <- which(XX.Days.start-XX.Days.end == days.in_today.month)
    XX.Days.start <- XX.Days.start[-pos.remove]
    XX.Days.end <- XX.Days.end[-pos.remove]
  }
  
  XX.length <- min(length(XX.Days.start),length(XX.Days.end))
  if (XX.length > 0){
    Days_XX.XX <- paste0("Days_",XX.Days.start[1:XX.length],".",XX.Days.end[1:XX.length], collapse = " + ")
  } else{
    Days_XX.XX <- c()
  }
  
  Xparty <- paste0(" c + ", single.days, single.months, Days_XX.XX)
  if (length(Days_XX.XX) == 0){
    Xparty <- substr(Xparty,1,nchar(Xparty)-3)
  }
  
  #   Trends & Dummies
  if (I.want.trend == "yes"){
    Xparty <- paste0(Xparty, " + trend")
  }
  if (I.want.trendQ == "yes"){
    Xparty <- paste0(Xparty, " + trendQ")
  }
  if (I.want.summerD == "yes"){
    Xparty <- paste0(Xparty, " + summer")
  }
  if (I.want.winterD == "yes"){
    Xparty <- paste0(Xparty, " + winter")
  }
  if (length(monthlyD) > 0){
    Xparty <- paste0(Xparty, " + " ,paste0("D", monthlyD, collapse = " + " ))
  }
  
  output <- list(single.days.vec, single.months.vec, Days_XX.XX, Xparty, today.month,mon.shifted)
  names(output) <- c("single.days.vec", "single.months.vec", "Days_XX.XX", "Xparty","today.month","mon.shifted")
  
  return(output)
  
}