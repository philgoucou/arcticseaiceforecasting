h002_buildxparty <- function(m.star,mon, today.month,
                             ICE_data,single.days.vec,single.months.vec,
                              list_XX.XX, Days_XX.XX,
                              I.want.trend, I.want.trendQ,
                              I.want.summerD, I.want.winterD,
                              monthlyD,I.want.realobs,I.want.subset.of.syn.months, list.vars) {
  
  # Are there any regressors that need to be shifted by a year?
  # --->    If "today.month == JUN" and one of the regressors is in "c("JUL","AUG","SEP","OCT","NOV","DEC")", 
  #         we need to shift them by one year (== 12 rows)
  if (FALSE){
  if (today.month == "sDEC"){
    if (m.star == "sDEC"){
      mon.t <- mon[-(which(mon == today.month))]
      mon.t1 <- c()
    } else {
      mon.t <- c()
      mon.t1 <- mon
    }
  } else if (today.month == "sJAN"){
    mon.t <- c()
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  } else  {
    mon.t <- mon[1:(which(mon == today.month) - 1)]
    mon.t1 <- mon[(which(mon == today.month) + 1):length(mon)]
  }
  }
  
  
  pos.today.month <- which(mon == today.month)
  pos.m.star <- which(mon == m.star)
  
  if (pos.today.month > pos.m.star){
    if (pos.today.month %in% c(9,10,11,12) & pos.m.star %in% c(1,2,3,4)){
      mon.t <- c()
      mon.t1 <- mon[1:(which(mon == today.month))]
      if (pos.today.month == 12){mon.t2 <- c()}else{mon.t2 <- mon[min(which(mon == today.month)+1,length(mon)):length(mon)]}
    } else {
      mon.t <- mon[1:(which(mon == today.month) - 1)]
      mon.t1 <- mon[min(which(mon == today.month) + 1,length(mon)):length(mon)]
      mon.t2 <- c()
    }
  } else {
    if (pos.today.month > 1){mon.t <- mon[1:(pos.today.month-1)]}else{mon.t <- c()}
    if (pos.today.month == 12){mon.t1 <- c()}else{mon.t1 <- mon[min(which(mon == today.month)+1,length(mon)):length(mon)]}
    mon.t2 <- c()
  }
  
  Xparty.df <- data.frame("Year" =  ICE_data$Year,"c" = rep(1, times= length(ICE_data$Year)),
                          "month" = ICE_data$month)
  
  # I)    "single.days"
  if (length(single.days.vec) > 0){
    single.days.df <- data.frame(matrix(NA,nrow=nrow(ICE_data),ncol=length(single.days.vec),
                                        dimnames = list(c(),single.days.vec)))
    for (ll in 1:length(single.days.vec)){
      # Which is the current month? ---> take out a potential "prefix"
      dot.pos <- regexpr(pattern = "\\.",single.days.vec[ll])
      if (dot.pos[[1]] < 0){
        month.ll <- substr(single.days.vec[ll],1,4)
      } else {
        month.ll <- paste0("s",substr(single.days.vec[ll],dot.pos[[1]] + 1,dot.pos[[1]] + 3))
      }
      
      # Shift the series "single.days.vec[ll]" if it is among "mon.t1"
      if (month.ll %in% mon.t1){
        if (I.want.realobs == "yes"){
          single.days.df[,single.days.vec[ll]] <- c(NA, ICE_data[1:(nrow(ICE_data)-1),single.days.vec[ll]])
        } else{
          single.days.df[,single.days.vec[ll]] <- c(rep(NA,times=12), ICE_data[1:(nrow(ICE_data)-12),single.days.vec[ll]])
        }
      } else {
        single.days.df[,single.days.vec[ll]] <- ICE_data[,single.days.vec[ll]]
      }
    }
    Xparty.df <- cbind(Xparty.df, single.days.df)
  }
  
  # II)   "single.months"
  if (length(single.months.vec) > 0){
    single.months.df <- data.frame(matrix(NA,nrow=nrow(ICE_data),ncol=length(single.months.vec),
                                          dimnames = list(c(),single.months.vec)))
    for (ll in 1:length(single.months.vec)){
      # Which is the current month? ---> take out a potential "prefix"
      dot.pos <- regexpr(pattern = "\\.",single.months.vec[ll])
      if (dot.pos[[1]] < 0){
        month.ll <- substr(single.months.vec[ll],1,4)
      } else {
        month.ll <- paste0("s",substr(single.months.vec[ll],dot.pos[[1]] + 1,dot.pos[[1]] + 3))
      }
      
      
      # Shift the series "single.months.vec[ll]" if it is among "mon.t1"
      if (month.ll %in% mon.t1){
        if (I.want.realobs == "yes"){
          single.months.df[,single.months.vec[ll]] <- c(NA,ICE_data[1:(nrow(ICE_data)-1),single.months.vec[ll]])
        } else{
          single.months.df[,single.months.vec[ll]] <- c(rep(NA,times=12), 
                                                        ICE_data[1:(nrow(ICE_data)-12),single.months.vec[ll]])
        }
      } else {
        single.months.df[,single.months.vec[ll]] <- ICE_data[,single.months.vec[ll]]
      }
    }
    Xparty.df <- cbind(Xparty.df, single.months.df)
  }
  
  # III)    "Days_XX.XX" ---> the average over "Days_XX.XX" when standing at "r"
  if (length(list_XX.XX) > 0){
    
    #   First, prepare a storage data-frame
    r_list_XX.XX <- list(NA)
    
    #   Run over the number of variables 
    for (xx in 1:length(list_XX.XX)){
      
      if (length(list_XX.XX[[xx]]) > 0){
        
        #   Prepare data-frames for regressor that you want to build from variable "xx"
        r_list_XX.XX_xx <- list() #rep(list(NA), length(list_XX.XX[[xx]]))
        
        #   Run over the number of regressors, i.e. length(Days_XX.XX)
        for (ll in 1:length(list_XX.XX[[xx]])){
          
          # Check if the "Days_XX.XX" might be redundant
          names_Days_XX.XX <- unlist(strsplit(Days_XX.XX, " + ", fixed = T))
          
          if (names(list_XX.XX[[xx]])[ll] %in% names_Days_XX.XX){
          
            r_df_XX.XX_xx <- data.frame(matrix(NA,nrow=nrow(ICE_data),ncol=length(list_XX.XX[[xx]][[ll]])-3,
                                            dimnames = list(c(),
                                                            as.character(list_XX.XX[[xx]][[ll]][r,4:length(list_XX.XX[[xx]][[ll]])]))))
            #   Run over the days over which Days_XX.XX[ll] shall be computed
            for (dd in 1:ncol(r_df_XX.XX_xx)){
              # Which is the current month? ---> take out a potential "prefix"
              dot.pos <- regexpr(pattern = "\\.",colnames(r_df_XX.XX_xx)[dd])
              if (dot.pos[[1]] < 0){
                month.dd <- substr(colnames(r_df_XX.XX_xx)[dd],1,4)
              } else {
                month.dd <- paste0("s",substr(colnames(r_df_XX.XX_xx)[dd],dot.pos[[1]] + 1,dot.pos[[1]] + 3))
              }
    
              # Shift the series "colnames(r_df_XX.XX_xx)[dd]" if it is among "mon.t1"
              if (month.dd %in% mon.t1){
                if (I.want.realobs == "yes"){
                  r_df_XX.XX_xx[,colnames(r_df_XX.XX_xx)[dd]] <- c(NA, ICE_data[1:(nrow(ICE_data)-1),
                                                                                colnames(r_df_XX.XX_xx)[dd]])
                } else{
                  r_df_XX.XX_xx[,colnames(r_df_XX.XX_xx)[dd]] <- c(rep(NA,times=12), 
                                                             ICE_data[1:(nrow(ICE_data)-12),colnames(r_df_XX.XX_xx)[dd]])
                }
                
              } else {
                r_df_XX.XX_xx[,colnames(r_df_XX.XX_xx)[dd]] <- ICE_data[,colnames(r_df_XX.XX_xx)[dd]]
              }
            } # This ends: for (dd in 1:ncol(r_df_XX.XX_xx)){
            
            r_list_XX.XX_xx[[names(list_XX.XX[[xx]])[ll]]] <- r_df_XX.XX_xx
            #names(r_list_XX.XX_xx)[ll] <- 
          } #This ends the if-statement for redundancy
          # Build next regressor
        }
        
        if (length(r_list_XX.XX_xx) > 0){
          r_list_XX.XX[[xx]] <- r_list_XX.XX_xx
        }
      }
    # Next "xx"
    }
    
    #   Second, compute each regressor ----> row-means for each dataframe in the list "r_list_XX.XX"
    names_Days_XX.XX <- unlist(strsplit(Days_XX.XX, " + ", fixed = T))
    Days_XX.XX.df <- data.frame(matrix(NA,nrow=nrow(ICE_data),ncol=length(names_Days_XX.XX),
                                       dimnames = list(c(),c(names_Days_XX.XX))))
    if (length(r_list_XX.XX) > 0){
      for (xx in 1:length(r_list_XX.XX)){
        if (length(r_list_XX.XX[[xx]]) > 0){
          for (ll in 1:length(r_list_XX.XX[[xx]])){
            if (names(r_list_XX.XX[[xx]])[ll] %in% colnames(Days_XX.XX.df)){
              Days_XX.XX.df[,names(r_list_XX.XX[[xx]])[ll]] <- apply(r_list_XX.XX[[xx]][[ll]], 1, mean, na.rm = T)
            }
          }
        }
      }
    }
    Days_XX.XX.df[Days_XX.XX.df == "NaN"] <- NA
    
    Xparty.df <- cbind(Xparty.df, Days_XX.XX.df)
    
  } # This ends: if (length(list_XX.XX) > 0){
  
  
  #   IV)     Trends & Dummies
  if (I.want.summerD == "yes"){
    Xparty.df$summer <- ICE_data$summer
  }
  if (I.want.winterD == "yes"){
    Xparty.df$winter <- ICE_data$winter
  }
  if (length(monthlyD) > 0){
    Xparty.df <- cbind(Xparty.df, ICE_data[,paste0("D",monthlyD)])
  }
  if (length(I.want.subset.of.syn.months) > 0){
    Xparty.df <- Xparty.df[which(Xparty.df$month %in% I.want.subset.of.syn.months),]
  }    
  if (I.want.trend == "yes"){
    Xparty.df$trend <- c(1:nrow(Xparty.df))
    #Xparty.df$trend <- ICE_data$trend
  }
  if (I.want.trendQ == "yes"){
    Xparty.df$trendQ <- Xparty.df$trend^2
  }

  
  return(Xparty.df)
  
} 