getSynPanel_SIT <- function(df, prefix){  
  
  
  mon <- paste0(prefix, c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))
  daily.colnames <- c()
  
  for (m in mon){
    if (m %in% paste0(prefix, c("JAN", "MAR", "MAY", "JUL", "AUG", "OCT", "DEC"))){
      daily.colnames <- c(daily.colnames, paste0(m, c(1:31),"_", c(1:31)))
    } else if (m %in% paste0(prefix,c("APR", "JUN", "SEP", "NOV"))){
      daily.colnames <- c(daily.colnames, paste0(m, c(1:30),"_", c(1:30)))
    } else if (m == paste0(prefix, "FEB")){
      daily.colnames <- c(daily.colnames, paste0(m, c(1:28),"_",c(1:28)))
    }
  }
  
  df_synthetic.panel <- data.frame(matrix(NA, nrow = nrow(df) * 12, ncol = ncol(df),
                                          dimnames = list(c(),colnames(df))))
  df_synthetic.panel$Year <- rep(df$Year, each = 12)
  
  for (yy in df$Year){
    
    for (cc in colnames(df_synthetic.panel)[2:ncol(df_synthetic.panel)]){
      
      #   Check if we are currently looking at a Month or a Day
      if (nchar(cc) == (1 + nchar(prefix) + 3)){
        
        # Which is the current month?
        mon.cc <- substr(cc,2,nchar(cc))
        
        # Which months to take from the current year "t" which months to take from the previous year "t-1"?
        if (mon.cc == paste0(prefix, "DEC")){
          mon.t <- mon[-(which(mon == mon.cc))]
          mon.t1 <- NA
        } else if (mon.cc == paste0(prefix, "JAN")){
          mon.t <- NA
          mon.t1 <- mon[(which(mon == mon.cc) + 1):length(mon)]
        } else  {
          mon.t <- mon[1:(which(mon == mon.cc) - 1)]
          mon.t1 <- mon[(which(mon == mon.cc) + 1):length(mon)]
        }
        
        
        # Set "mon.cc" at the last observation of year "t"
        last.yy <- which(df_synthetic.panel$Year == yy)[length(which(df_synthetic.panel$Year == yy))]
        df_synthetic.panel[last.yy, cc] <- df[which(df$Year == yy), cc]
        
        
        if (!all(is.na(mon.t)) && !all(is.na(mon.t1)) ){
          
          mon.t.t1 <- c(mon.t1,mon.t)
          
          # Set "mon.t" below the observation for "mon.cc"
          for (mm in rev(mon.t)){
            
            position.mm <- which(rev(mon.t.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            mm.value <- df[which(df$Year == yy), paste0("s",mm)]
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t)){
          
          # Set "mon.t1" below the observations for "mon.t"
          for (mm in rev(mon.t1)){
            
            position.mm <- which(rev(mon.t.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            mm.value <- df[which(df$Year == yy - 1), paste0("s",mm)]
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t1)){
          
          
        } else if (all(is.na(mon.t))){
          
          # Set "mon.t1" below the observations for "mon.cc"
          for (mm in rev(mon.t1)){
            
            position.mm <- which(rev(mon.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            mm.value <- df[which(df$Year == yy - 1), paste0("s",mm)]
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t1)){
          
        } else if (all(is.na(mon.t1))){
          
          # Set "mon.t" below the observation for "mon.cc"
          for (mm in rev(mon.t)){
            
            position.mm <- which(rev(mon.t) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            mm.value <- df[which(df$Year == yy), paste0("s",mm)]
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t)){
          
        } # This ends: if (!all(is.na(mon.t))){
        
        
      } else {
        
        # Which is the current day?
        mon.day <- substr(cc,(1 + nchar(prefix) + 1 + 3),nchar(cc))
        
        # Which is the current month?
        mon.cc <- substr(cc,2,1 + nchar(prefix) + 3)
        
        # Which months to take from the current year "t" which months to take from the previous year "t-1"?
        if (mon.cc == paste0(prefix, "DEC")){
          mon.t <- mon[-(which(mon == mon.cc))]
          mon.t1 <- NA
        } else if (mon.cc == paste0(prefix,"JAN")){
          mon.t <- NA
          mon.t1 <- mon[(which(mon == mon.cc) + 1):length(mon)]
        } else  {
          mon.t <- mon[1:(which(mon == mon.cc) - 1)]
          mon.t1 <- mon[(which(mon == mon.cc) + 1):length(mon)]
        }
        
        
        # Set "cc" at the last observation of year "t"
        last.yy <- which(df_synthetic.panel$Year == yy)[length(which(df_synthetic.panel$Year == yy))]
        df_synthetic.panel[last.yy, cc] <- df[which(df$Year == yy), cc]
        
        
        if (!all(is.na(mon.t)) && !all(is.na(mon.t1)) ){
          
          mon.t.t1 <- c(mon.t1,mon.t)
          
          # Set "mon.t" below the observation for "mon.cc"
          for (mm in rev(mon.t)){
            
            position.mm <- which(rev(mon.t.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            if (length(which(colnames(df) == paste0("s",mm,mon.day))) > 0){
              mm.value <- df[which(df$Year == yy), paste0("s",mm,mon.day)]
            } else {
              mm.days <- daily.colnames[grep(mm,daily.colnames)]
              separator <- unlist(gregexpr(pattern ='_',mm.days))
              mm.days.number <- as.numeric(substr(mm.days,separator + 1, nchar(mm.days)))
              mm.value <- df[which(df$Year == yy), paste0("s",mm,max(mm.days.number),"_",max(mm.days.number))]
            }
            
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t)){
          
          # Set "mon.t1" below the observations for "mon.t"
          for (mm in rev(mon.t1)){
            
            position.mm <- which(rev(mon.t.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            if (length(which(colnames(df) == paste0("s",mm,mon.day))) > 0){
              mm.value <- df[which(df$Year == yy - 1), paste0("s",mm,mon.day)]
            } else {
              mm.days <- daily.colnames[grep(mm,daily.colnames)]
              separator <- unlist(gregexpr(pattern ='_',mm.days))
              mm.days.number <- as.numeric(substr(mm.days,separator + 1, nchar(mm.days)))
              mm.value <- df[which(df$Year == yy - 1), paste0("s",mm,max(mm.days.number),"_",max(mm.days.number))]
            }
            
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t1)){
          
          
        } else if (all(is.na(mon.t))){
          
          # Set "mon.t1" below the observations for "mon.cc"
          for (mm in rev(mon.t1)){
            
            position.mm <- which(rev(mon.t1) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            if (length(which(colnames(df) == paste0("s",mm,mon.day))) > 0){
              mm.value <- df[which(df$Year == yy - 1), paste0("s",mm,mon.day)]
            } else {
              mm.days <- daily.colnames[grep(mm,daily.colnames)]
              separator <- unlist(gregexpr(pattern ='_',mm.days))
              mm.days.number <- as.numeric(substr(mm.days,separator + 1, nchar(mm.days)))
              mm.value <- df[which(df$Year == yy - 1), paste0("s",mm,max(mm.days.number),"_",max(mm.days.number))]
            }
            
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t1)){
          
        } else if (all(is.na(mon.t1))){
          
          # Set "mon.t" below the observation for "mon.cc"
          for (mm in rev(mon.t)){
            
            position.mm <- which(rev(mon.t) == mm)
            
            # Check the "synthetic value" --- maybe there is no observation:
            if (length(which(colnames(df) == paste0("s",mm,mon.day))) > 0){
              mm.value <- df[which(df$Year == yy), paste0("s",mm,mon.day)]
            } else {
              mm.days <- daily.colnames[grep(mm,daily.colnames)]
              separator <- unlist(gregexpr(pattern ='_',mm.days))
              mm.days.number <- as.numeric(substr(mm.days,separator + 1, nchar(mm.days)))
              mm.value <- df[which(df$Year == yy), paste0("s",mm,max(mm.days.number),"_",max(mm.days.number))]
            }
            
            if (length(mm.value) > 0){
              df_synthetic.panel[last.yy - position.mm, cc] <- mm.value
            }
            
          } # This ends: for (mm in rev(mon.t)){
          
        } # This ends: if (!all(is.na(mon.t))){
        
        
        
      }  # This ends: (nchar(cc) == 4){
      
    } # This ends: for (cc in colnames(df_synthetic.panel)[2:ncol(df_synthetic.panel)]){
    
  }
  
  return(df_synthetic.panel)
  
}
