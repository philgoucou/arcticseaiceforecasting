getCO2 <- function(df, m.star, prefix){
  
  var.name <- gsub("\\.", "",prefix)
  
  ################################################################################################
  #
  #      00)  Missing Data Filled with Average of Adjacent Days --- Create a STACKED SII-Dataframe
  #
  ################################################################################################
  
  mon <- c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
  
  ################################################################################################
  #
  #      00)  Run a Monthly Dummy Regression
  #
  ################################################################################################
  df_help <- cbind(df,matrix(0,nrow=nrow(df), ncol=length(mon)))
  colnames(df_help)[4:ncol(df_help)] <- mon
  
  for (mm in 1:length(mon)){
    df_help[which(df_help$Month == mm), mon[mm]] <- 1
  }
  formula.dummy <- paste0(var.name, " ~ ",paste0(mon, collapse = " + "), " - 1")
  
  reg.dummy <- lm(as.formula(formula.dummy), data = df_help)
  summary(reg.dummy)
  
  
  #########################################################################################################################
  #
  #       I) Synthetic Months: Create a monthly panel-like dataframe, in which ALL months are "synthetic"-"m.star" months
  #
  #########################################################################################################################
  
  #   Start with the "Real Observations"
  df_monthly_df <- data.frame(matrix(NA, nrow = length(unique(df$Year)), ncol = 12, 
                                      dimnames = list(c(unique(df$Year)), c(1:12))), check.names = F)
  for (r in 1:nrow(df_monthly_df)){
    for (c in 1:ncol(df_monthly_df)){
      year.month_idx <- which(df$Year == as.numeric(rownames(df_monthly_df)[r]) & 
                                df$Month == as.numeric(colnames(df_monthly_df)[c]))
      df_monthly_df[r,c] <- mean(df[year.month_idx, var.name])
    }
  }
  
  colnames(df_monthly_df) <- paste0(prefix, 
                                    c("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"))
  df_monthly_df[df_monthly_df == "NaN"] <- NA
  
  #   Export the REAL OBSERVATIONS
  df_real.obs.panel <- df_monthly_df
  
  
  #   Start the Synthetic-Month-Computations
  df_monthly_synthetic <- data.frame(matrix(NA, nrow = nrow(df_monthly_df), ncol = 12,
                                             dimnames = list(rownames(df_monthly_df),paste0("s",prefix, mon))))
  m.star_coeff <- reg.dummy$coefficients[m.star]
  
  for (mm in 1:length(mon)){
    mm_coeff <- reg.dummy$coefficients[mon[mm]]
    syn.value <-  df_monthly_df[,paste0(prefix,mon[mm])] - mm_coeff + m.star_coeff
    df_monthly_synthetic[,paste0("s",prefix, mon[mm])] <- syn.value
  }
  
  df_synthetic_panel <- df_monthly_synthetic
  
  
  out <- list(df_real.obs.panel, df_synthetic_panel)
  names(out) <- c(paste0(var.name, "_real.obs.panel"), paste0(var.name, "_processed_nomissing_synthetic"))
  
  return(out)
}