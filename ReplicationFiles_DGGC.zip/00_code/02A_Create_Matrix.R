########################################################################################################################
#
#       Create Synthetic panel-dataset: 
#
#       -     Rows == years * months
#       -     Columns == months + days
#
#       Keep in Mind: for a given year, e.g. t=2000, SEP_t will be associated with OCT_{t-1}, NOV_{t-1}, and DEC_{t-1}
#
########################################################################################################################


############################# Columns are formed as follows  ######################################

#         !!!!!!    anchor == Year & m.star:   Which data points are known in Year t in Month m ???  !!!!

#     Year          c     Trend     sSEP==m.star ....   sJUN    ........    sJUL10_10      .....     sOCT10_10
# 
#     t=1989        1       131    sAUG_{t=1989}     sMAY_{t=1989}       sJUN10_10_{t=1989}       sSEP10_10_{t=1989}
#     t=1989        1       132    sSEP_{t=1989}     sJUN_{t=1989}       sJUL10_10_{t=1989}       sOCT10_10_{t=1989}
#     t=1990        1       133    sOCT_{t=1989}     sJUL_{t=1989}       sAUG10_10_{t=1989}       sNOV10_10_{t=1989}
#     t=1990        1       134    sNOV_{t=1989}     sAUG_{t=1989}       sSEP10_10_{t=1989}       sDEC10_10_{t=1989}
#     t=1990        1       135    sDEC_{t=1989}     sSEP_{t=1989}       sOCT10_10_{t=1989}       sJAN10_10_{t=1990}
#     t=1990        1       136    sJAN_{t=1990}     sOCT_{t=1989}       sNOV10_10_{t=1989}       sFEB10_10_{t=1990}
#     t=1990        1       137    sFEB_{t=1990}     sNOV_{t=1989}       sDEC10_10_{t=1989}       sMAR10_10_{t=1990}
#     t=1990        1       138    sMAR_{t=1990}     sDEC_{t=1989}       sJAN10_10_{t=1990}       sAPR10_10_{t=1990}
#     t=1990        1       139    sAPR_{t=1990}     sJAN_{t=1990}       sFEB10_10_{t=1990}       sMAY10_10_{t=1990}
#     t=1990        1       140    sMAY_{t=1990}     sFEB_{t=1990}       sMAR10_10_{t=1990}       sJUN10_10_{t=1990}
#     t=1990        1       141    sJUN_{t=1990}     sMAR_{t=1990}       sAPR10_10_{t=1990}       sJUL10_10_{t=1990}
#     t=1990        1       142    sJUL_{t=1990}     sAPR_{t=1990}       sMAY10_10_{t=1990}       sAUG10_10_{t=1990}
#     t=1990        1       143    sAUG_{t=1990}     sMAY_{t=1990}       sJUN10_10_{t=1990}       sSEP10_10_{t=1990}
#     t=1990        1       144    sSEP_{t=1990}     sJUN_{t=1990}       sJUL10_10_{t=1990}       sOCT10_10_{t=1990}
#     t=1991        1       145    sOCT_{t=1990}     sJUL_{t=1990}       sAUG10_10_{t=1990}       sNOV10_10_{t=1990}
#     t=1991        1       146    sNOV_{t=1990}     sAUG_{t=1990}       sSEP10_10_{t=1990}       sDEC10_10_{t=1990}
#     t=1991        1       147    sDEC_{t=1990}     sSEP_{t=1990}       sOCT10_10_{t=1990}       sJAN10_10_{t=1991}
#     t=1991        1       148    sJAN_{t=1991}     sOCT_{t=1990}       sNOV10_10_{t=1990}       sFEB10_10_{t=1991}
#
#
#
#           If some months do not have a certain day: e.g. FEB 29th, FEB 30th, APR 31st etc.
#           ----> Then "sMAR31_31" has "sFEB28_28" at the FEB-position, and "sAPR30_30" at the APR-position respectively
#
#
########################################################################################################################
rm(list = ls())

# ============================================== USER INTERACTION: Start ============================================== #

directory <- "/Users/maximilian/Dropbox/ReplicationFiles"

# ============================================== USER INTERACTION: Start ============================================== #


for (mm in c("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC")){
    for (ind in c("CO2","AT")){ 
      
#   Which is your target-month (Y-Variable)?
m.star <- mm #"SEP"

#   Which series do you want to prepare?
#   "SII" = Sea Ice Index (Extent); "SIT" = PIOMAS Thickness; "CO2" = Mauna Loa Global CO2; "AT" = NH Temperature Anomaly
I.want.ICE <- ind #"SII" 

#   Do you want the data to be in First-Differences? ["yes"/"no"] --> only for: CO2
if (ind %in% c("CO2","AT")){
  I.want.FD <- "no"
} else{
  I.want.FD <- "no"
}


#   Load the already processed data
if (I.want.ICE == "SII"){
  SII_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/SII_processed_nomissing_synthetic", m.star ,".csv")))
  colnames(SII_df)[1] <- "Year"
  prefix <- c()
} else if (I.want.ICE == "SIT"){
  SIT_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/SIT_processed_nomissing_synthetic", m.star ,".csv")))
  colnames(SIT_df)[1] <- "Year"
  prefix <- c("SIT.")
} else if (I.want.ICE == "CO2"){
  if (I.want.FD == "yes"){
    CO2_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/CO2_processed_nomissing_synthetic", m.star ,"_FD.csv")))
  } else {
    CO2_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/CO2_processed_nomissing_synthetic", m.star ,".csv")))
  }
  colnames(CO2_df)[1] <- "Year"
  prefix <- c("CO2.")
} else if (I.want.ICE == "AT"){
  if (I.want.FD == "yes"){
    AT_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/AT_processed_nomissing_synthetic", m.star ,"_FD.csv")))
  } else {
    AT_df <- read.csv(file.path(directory,paste0("10_data/SyntheticData/AT_processed_nomissing_synthetic", m.star ,".csv")))
  }
  colnames(AT_df)[1] <- "Year"
  prefix <- c("AT.")
}


#   Prepare the synthetic panel as described above
if (I.want.ICE == "SII"){

  source(file = file.path(directory,"00_code/001_functions/getSynPanel_SII.R"))
  sSII.panel <- getSynPanel_SII(SII_df)
  
  #     Export the stuff
  write.csv(sSII.panel, 
            file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,".csv")), 
            row.names = F)
  
} else if (I.want.ICE == "SIT"){
  
  source(file = file.path(directory,"00_code/001_functions/getSynPanel_SIT.R"))
  sSIT.panel <- getSynPanel_SIT(SIT_df, prefix)
  
  #     Export the stuff
  write.csv(sSIT.panel, 
            file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,".csv")), 
            row.names = F)
} else if (I.want.ICE == "CO2"){
  
  source(file = file.path(directory,"00_code/001_functions/getSynPanel_SIT.R"))
  sCO2.panel <- getSynPanel_SIT(CO2_df, prefix)
  
  #     Export the stuff
  if (I.want.FD == "yes"){
    write.csv(sCO2.panel, 
              file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,"_FD.csv")), 
              row.names = F)
  } else {
    write.csv(sCO2.panel, 
              file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,".csv")), 
              row.names = F)
  }
} else if (I.want.ICE == "AT"){
  
  source(file = file.path(directory,"00_code/001_functions/getSynPanel_SIT.R"))
  sAT.panel <- getSynPanel_SIT(AT_df, prefix)
  
  #     Export the stuff
  if (I.want.FD == "yes"){
    write.csv(sAT.panel, 
              file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,"_FD.csv")), 
              row.names = F)
  } else {
    write.csv(sAT.panel, 
              file = file.path(directory,paste0("10_data/SyntheticData/",I.want.ICE,"_SyntheticPanel_", m.star ,".csv")), 
              row.names = F)
  }
}

}}
