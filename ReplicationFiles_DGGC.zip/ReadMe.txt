% ===================================================================== %
%
%		    ReadMe for Replication Files:
%
%		Diebold, Goebel, Goulet Coulombe (2022)
%
% ===================================================================== %



% ----------------- Step 1: Download & Pre-Process the Data ------------------- %

Code File:		00_RawData_Download_CleanUp.py	

Output File:

	- Storage:	[10_data]
	- Naming: 	"AT_monthly.csv" & "CO2_monthly.csv" & "SIT_Daily.csv" & "SeaIceIndex_Daily.csv"		

Remarks:			- search for "USER INTERACTION"
			- 'AT' may only be available until the end of the PREVIOUS year. 
			  --> for the output-file to be compatible with the code further
 			      down the road, lines 271-276 add 'NAs' for the current year
			  --> once data for the CURRENT year becomes available, 
			      you may want to comment out these lines.



% ----------------- Step 2: Further Pre-Processing ------------------- %
%
%  Feature Engineering:
%  -	calculation of monthly values from daily data 
%  -	calculation of Synthetic Data
%  -	calculation of first-differences


Code File:	

	- Step 2.1:	01_Make_DaysMonths.R
	- Step 2.2:	01A_Make_DaysMonths.R
	- Step 2.3:	02_Create_Matrix.R
	- Step 2.4:	02A_Create_Matrix.R

Output File:		

	- Storage:	[10_data/101_output/]


Remark:			Folder "SyntheticData" is currently empty. But you need the files to proceed with the estimation. There are two options:

			I)	You run through Steps 2.1 - 2.4 as described above 
				and you're all set
			II)	You download the files (hard copies made on June, 7 2022) 
				via the following link into the folder "SyntheticData":


	https://drive.google.com/drive/folders/1badXFNESauQOVzKrXYhrjzwieA-zg4Hn?usp=sharing



% -------------------- Step 3: Estimation ---------------------- %

Code File:		03_MAIN.R

Input File:
	
	- Loaded from:	[10_data] & [10_data/SyntheticData]

Output File:		

	- Storage:	[10_data/101_output/]
	- Naming:	"s" + MONTH + "_" + YEAR OF PREDICTION + ".RData"	

Remarks:			User Interaction (lines 12-26)	


% -------------------- Step 4: Plotting ---------------------- %

Code File:		04_Figures.R


ATTENTION:		The replication files come without the output of Step 3.
			In order to plot the figures, there are two possibilities: 

			I)	you either run Step 3 with the default settings (line 18 & 24)
			II)	you download the necessary files (i.e. all files and folders) 
				via the following link and copy it into folder "101_output":


	https://drive.google.com/drive/folders/1P9oXncw_QduHr0Fsikw2l9h4b9_BsMIn?usp=sharing


			----> Once you have the output files of Step 3, you can proceed


Input Files:		

	- Storage:	[10_data/101_output/]
	- Naming:	"s" + MONTH + "_" + YEAR OF PREDICTION + ".RData"


Output:		

	- Storage:	[20_figures/]


Remarks:			User Interaction (lines 20-24)

	